package com.rmc.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.rmc.bean.Admin;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.dao.LoginDAO;
import com.rmc.dao.LoginDAOImpl;
import com.rmc.resources.AppConfig;

@Path("/LoginAPI")
public class LoginAPI {
	@POST
	@Path("/Admin")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAdminDetails(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		LoginDAO login = new LoginDAOImpl();
		Admin admin = gson.fromJson(dataRecieved, Admin.class);
		try {
			Admin admin2 = login.getAdminDetails(admin.getAdminEmail(), admin.getAdminPassword());
			String value = gson.toJson(admin2);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@POST
	@Path("/Student")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudentDetails(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		LoginDAO login = new LoginDAOImpl();
		Student student = gson.fromJson(dataRecieved, Student.class);
		try {
			Student student2 = login.getStudentDetails(student.getStudentEmail(), student.getStudentPassword());
			String value = gson.toJson(student2);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@POST
	@Path("/Parent")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getParentDetails(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		LoginDAO login = new LoginDAOImpl();
		Parent parent = gson.fromJson(dataRecieved, Parent.class);
		try {
			Parent parent2 = login.getParentDetails(parent.getParentEmail(), parent.getParentPassword());
			String value = gson.toJson(parent2);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}
}