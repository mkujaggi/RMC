package com.rmc.bean;

import java.util.Calendar;

public class Attendance {
	private Integer attendanceId;
	private Calendar attendanceDate;
	private Integer studentId;
	private Boolean studentStatus;

	public Integer getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(Integer attendanceId) {
		this.attendanceId = attendanceId;
	}

	public Calendar getAttendanceDate() {
		return attendanceDate;
	}

	public void setAttendanceDate(Calendar attendanceDate) {
		this.attendanceDate = attendanceDate;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Boolean getStudentStatus() {
		return studentStatus;
	}

	public void setStudentStatus(Boolean studentStatus) {
		this.studentStatus = studentStatus;
	}

}
