package com.rmc.dao;

import java.util.List;

import com.rmc.bean.Attendance;
import com.rmc.bean.Message;
import com.rmc.bean.Student;
import com.rmc.bean.Test;
import com.rmc.bean.TestStudent;

public interface StudentAndParentDAO {
	public List<Attendance> getAllAttendance() throws Exception;

	public List<Student> getAllDetails() throws Exception;

	public byte[] getImage(Integer studentId) throws Exception;

	public List<TestStudent> getAllTestsGivenByStudent() throws Exception;

	public List<Test> getAllTests() throws Exception;

	public byte[] getAnswerSheetForStudent(Integer testId, Integer studentId) throws Exception;

	public byte[] getQuestionPaper(Integer testId) throws Exception;

	public void sendMessageFromStudent(Integer studentId, String message) throws Exception;

	public void sendMessageFromParent(Integer parentId, String message) throws Exception;

	public List<Message> getAllMessages() throws Exception;
}
