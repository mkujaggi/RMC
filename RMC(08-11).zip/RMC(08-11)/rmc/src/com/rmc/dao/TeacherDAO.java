package com.rmc.dao;

import java.util.HashMap;
import java.util.List;

import com.rmc.bean.Address;
import com.rmc.bean.Attendance;
import com.rmc.bean.Message;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;

public interface TeacherDAO {
	public Integer addNewStudent(Student student) throws Exception;

	public List<Student> getAllStudents() throws Exception;

	public byte[] getAdminPicture(Integer adminId) throws Exception;

	public void updateAdminPicture(Integer adminId, byte[] adminPicture) throws Exception;

	public void deleteAdminPicture(Integer adminId) throws Exception;

	public String deleteStudent(Integer studentId) throws Exception;

	public void updateStudent(Student student) throws Exception;

	public void updateStudentAddress(Integer studentId, Address address) throws Exception;

	public void updateStudentParent(Integer studentId, Parent parent) throws Exception;

	public byte[] getStudentPicture(Integer studentId) throws Exception;

	public void updateStudentPicture(Integer studentId, byte[] studentPicture) throws Exception;

	public void deleteStudentPicture(Integer studentId) throws Exception;

	public void updateStudentFee(HashMap<Integer, Boolean> feesMap) throws Exception;

	public void refreshFees() throws Exception;

	public void updateStudentAttendance(HashMap<Integer, Boolean> feesMap) throws Exception;

	public List<Attendance> getAllAttendance() throws Exception;

	public List<Message> getAllMessages() throws Exception;
}
