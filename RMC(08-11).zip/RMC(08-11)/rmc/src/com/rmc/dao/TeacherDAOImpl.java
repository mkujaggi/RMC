package com.rmc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.bean.Address;
import com.rmc.bean.Attendance;
import com.rmc.bean.Message;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.entity.AddressEntity;
import com.rmc.entity.AdminEntity;
import com.rmc.entity.ParentEntity;
import com.rmc.entity.StudentEntity;
import com.rmc.resources.HibernateUtility;

public class TeacherDAOImpl implements TeacherDAO {

	/*
	 * This method receives a student bean input, first it checks whether the
	 * student email or phone is already allocated to someone else and similarly
	 * it checks for the parent email and phone number. If all is good then it
	 * adds a new student into the database. It logs hibernate and normal
	 * exceptions and also re-throws them.
	 */
	@Override
	public Integer addNewStudent(Student student) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer studentId = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM StudentEntity se WHERE se.studentEmail= :email");
			q1.setParameter("email", student.getStudentEmail());
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			if (list1.isEmpty()) {
				Query q2 = session.createQuery("FROM StudentEntity se WHERE se.studentPhNumber= :number");
				q2.setParameter("number", student.getStudentPhNumber());
				@SuppressWarnings("unchecked")
				List<StudentEntity> list2 = q2.list();
				if (list2.isEmpty()) {
					Query q3 = session.createQuery("FROM ParentEntity pe WHERE pe.parentEmail= :email");
					q3.setParameter("email", student.getStudentEmail());
					@SuppressWarnings("unchecked")
					List<ParentEntity> list3 = q3.list();
					ParentEntity pe = new ParentEntity();
					if (list3.isEmpty()) {
						Query q4 = session.createQuery("FROM ParentEntity pe WHERE pe.parentPhNumber= :number");
						q4.setParameter("number", student.getStudentPhNumber());
						@SuppressWarnings("unchecked")
						List<ParentEntity> list4 = q4.list();
						if (list4.isEmpty()) {
							pe.setParentEmail(student.getStudentParent().getParentEmail());
							pe.setParentName(student.getStudentParent().getParentName());
							pe.setParentPassword(student.getStudentParent().getParentPassword());
							pe.setParentPhNumber(student.getStudentParent().getParentPhNumber());
							session.save(pe);
						} else {
							throw new Exception("UserDAO.PHONE_NO_TO_OTHER_PARENT");
						}
					} else {
						throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_PARENT");
					}
					AddressEntity ae = new AddressEntity();
					ae.setCity(student.getStudentAddress().getCity());
					ae.setHouseNumber(student.getStudentAddress().getHouseNumber());
					ae.setPinCode(student.getStudentAddress().getPinCode());
					ae.setSector(student.getStudentAddress().getSector());
					ae.setState(student.getStudentAddress().getState());
					session.save(ae);
					StudentEntity se = new StudentEntity();
					se.setStudentAddress(ae);
					se.setStudentClass(student.getStudentClass());
					se.setStudentDOB(student.getStudentDOB());
					se.setStudentEmail(student.getStudentEmail());
					se.setStudentFee(student.getStudentFee());
					se.setStudentGender(student.getStudentGender());
					se.setStudentName(student.getStudentName());
					se.setStudentParent(pe);
					se.setStudentPassword(student.getStudentPassword());
					se.setStudentPhNumber(student.getStudentPhNumber());
					studentId = (Integer) session.save(se);
					session.getTransaction().commit();
				} else {
					throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
				}
			} else {
				throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_STUDENT");
			}
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentId;
	}

	/*
	 * This method gets all the students from the database and throws an error
	 * if there are no students in the database
	 */
	@Override
	public List<Student> getAllStudents() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Student> finalList = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM StudentEntity");
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			if (list1.isEmpty()) {
				throw new Exception("UserDAO.NO_STUDENTS_IN_DATABASE");
			}
			for (StudentEntity se : list1) {
				Address a = new Address();
				a.setAddressId(se.getStudentAddress().getAddressId());
				a.setCity(se.getStudentAddress().getCity());
				a.setHouseNumber(se.getStudentAddress().getHouseNumber());
				a.setPinCode(se.getStudentAddress().getPinCode());
				a.setSector(se.getStudentAddress().getSector());
				a.setState(se.getStudentAddress().getState());
				Parent p = new Parent();
				p.setParentId(se.getStudentParent().getParentId());
				p.setParentEmail(se.getStudentParent().getParentEmail());
				p.setParentName(se.getStudentParent().getParentName());
				p.setParentPhNumber(se.getStudentParent().getParentPhNumber());
				p.setParentLastLogin(se.getStudentParent().getParentLastLogin());
				p.setParentTimesLogin(se.getStudentParent().getParentTimesLogin());
				Student s = new Student();
				s.setStudentAddress(a);
				s.setStudentParent(p);
				s.setStudentId(se.getStudentId());
				s.setStudentName(se.getStudentName());
				s.setStudentEmail(se.getStudentEmail());
				s.setStudentPhNumber(se.getStudentPhNumber());
				s.setStudentDOB(se.getStudentDOB());
				s.setStudentGender(se.getStudentGender());
				s.setStudentClass(se.getStudentClass());
				s.setStudentFee(se.getStudentFee());
				finalList.add(s);
			}
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return finalList;
	}

	@Override
	public byte[] getAdminPicture(Integer adminId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		byte[] adminImage = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM AdminEntity ae WHERE ae.adminId= :id");
			q1.setParameter("id", adminId);
			@SuppressWarnings("unchecked")
			List<AdminEntity> list1 = q1.list();
			AdminEntity ae = list1.get(0);
			adminImage = ae.getAdminImage();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return adminImage;
	}

	@Override
	public void updateAdminPicture(Integer adminId, byte[] adminPicture) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("UPDATE AdminEntity ae SET ae.adminImage= :image WHERE ae.adminId= :id");
			q1.setParameter("image", adminPicture);
			q1.setParameter("id", adminId);
			q1.executeUpdate();
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void deleteAdminPicture(Integer adminId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("UPDATE AdminEntity ae SET ae.adminImage= :image WHERE ae.adminId= :id");
			q1.setParameter("image", null);
			q1.setParameter("id", adminId);
			q1.executeUpdate();
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method receives a student Id and then it deletes all the student
	 * details from the database including address and parent
	 */
	@Override
	public String deleteStudent(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		String studName = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q1.setParameter(0, studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			studName = list1.get(0).getStudentName();
			Query q2 = session.createQuery("DELETE FROM StudentEntity se WHERE se.studentId=?");
			q2.setParameter(0, studentId);
			q2.executeUpdate();
			Query q3 = session.createQuery("DELETE FROM ParentEntity pe WHERE pe.parentId=?");
			q3.setParameter(0, list1.get(0).getStudentParent().getParentId());
			q3.executeUpdate();
			Query q4 = session.createQuery("DELETE FROM AddressEntity ae WHERE ae.addressId=?");
			q4.setParameter(0, list1.get(0).getStudentAddress().getAddressId());
			q4.executeUpdate();
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studName;
	}

	/*
	 * This method receives a student bean which needs to be updated. First it
	 * fetches the student from the database and then it checks whether the
	 * email id or phone number from the student bean has been changed or not.
	 * If it is not changed then it updates the student but if it is changed
	 * then it checks that if the changed email or phone has been alloted to
	 * some parent or student, if it is given to someone else then it throws a
	 * particular error
	 */
	@Override
	public void updateStudent(Student student) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM StudentEntity se WHERE se.studentId= :id");
			q1.setParameter("id", student.getStudentId());
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			StudentEntity se = list1.get(0);
			if (se.getStudentEmail().equals(student.getStudentEmail())) {
				if (se.getStudentPhNumber().equals(student.getStudentPhNumber())) {
					Query q2 = session.createQuery(
							"UPDATE StudentEntity se SET se.studentName= :name,se.studentEmail= :email,se.studentPhNumber= :phone,se.studentDOB= :dob,se.studentClass= :class,se.studentGender= :gender WHERE se.studentId= :id");
					q2.setParameter("name", student.getStudentName());
					q2.setParameter("email", student.getStudentEmail());
					q2.setParameter("phone", student.getStudentPhNumber());
					q2.setParameter("dob", student.getStudentDOB());
					q2.setParameter("class", student.getStudentClass());
					q2.setParameter("gender", student.getStudentGender());
					q2.setParameter("id", student.getStudentId());
					q2.executeUpdate();
				} else if (!se.getStudentPhNumber().equals(student.getStudentPhNumber())) {
					Query q3 = session.createQuery("FROM StudentEntity se WHERE se.studentPhNumber= :number");
					q3.setParameter("number", student.getStudentPhNumber());
					@SuppressWarnings("unchecked")
					List<StudentEntity> list2 = q3.list();
					if (list2.isEmpty()) {
						Query q4 = session.createQuery("FROM ParentEntity pe WHERE pe.parentPhNumber= :number");
						q4.setParameter("number", student.getStudentPhNumber());
						@SuppressWarnings("unchecked")
						List<ParentEntity> list3 = q4.list();
						if (list3.isEmpty()) {
							Query q5 = session.createQuery(
									"UPDATE StudentEntity se SET se.studentName= :name,se.studentEmail= :email,se.studentPhNumber= :phone,se.studentDOB= :dob,se.studentClass= :class,se.studentGender= :gender WHERE se.studentId= :id");
							q5.setParameter("name", student.getStudentName());
							q5.setParameter("email", student.getStudentEmail());
							q5.setParameter("phone", student.getStudentPhNumber());
							q5.setParameter("dob", student.getStudentDOB());
							q5.setParameter("class", student.getStudentClass());
							q5.setParameter("gender", student.getStudentGender());
							q5.setParameter("id", student.getStudentId());
							q5.executeUpdate();
						} else {
							throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
						}
					} else {
						throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
					}
				}
			} else if (!se.getStudentEmail().equals(student.getStudentEmail())) {
				Query q6 = session.createQuery("FROM StudentEntity se WHERE se.studentEmail= :email");
				q6.setParameter("email", student.getStudentEmail());
				@SuppressWarnings("unchecked")
				List<StudentEntity> list4 = q6.list();
				if (list4.isEmpty()) {
					Query q7 = session.createQuery("FROM ParentEntity pe WHERE pe.parentEmail= :email");
					q7.setParameter("email", student.getStudentEmail());
					@SuppressWarnings("unchecked")
					List<ParentEntity> list5 = q7.list();
					if (list5.isEmpty()) {
						if (se.getStudentPhNumber().equals(student.getStudentPhNumber())) {
							Query q8 = session.createQuery(
									"UPDATE StudentEntity se SET se.studentName= :name,se.studentEmail= :email,se.studentPhNumber= :phone,se.studentDOB= :dob,se.studentClass= :class,se.studentGender= :gender WHERE se.studentId= :id");
							q8.setParameter("name", student.getStudentName());
							q8.setParameter("email", student.getStudentEmail());
							q8.setParameter("phone", student.getStudentPhNumber());
							q8.setParameter("dob", student.getStudentDOB());
							q8.setParameter("class", student.getStudentClass());
							q8.setParameter("gender", student.getStudentGender());
							q8.setParameter("id", student.getStudentId());
							q8.executeUpdate();
						} else if (!se.getStudentPhNumber().equals(student.getStudentPhNumber())) {
							Query q9 = session.createQuery("FROM StudentEntity se WHERE se.studentPhNumber= :number");
							q9.setParameter("number", student.getStudentPhNumber());
							@SuppressWarnings("unchecked")
							List<StudentEntity> list6 = q9.list();
							if (list6.isEmpty()) {
								Query q10 = session
										.createQuery("FROM ParentEntity pe WHERE pe.parentPhNumber= :number");
								q10.setParameter("number", student.getStudentPhNumber());
								@SuppressWarnings("unchecked")
								List<ParentEntity> list7 = q10.list();
								if (list7.isEmpty()) {
									Query q11 = session.createQuery(
											"UPDATE StudentEntity se SET se.studentName= :name,se.studentEmail= :email,se.studentPhNumber= :phone,se.studentDOB= :dob,se.studentClass= :class,se.studentGender= :gender WHERE se.studentId= :id");
									q11.setParameter("name", student.getStudentName());
									q11.setParameter("email", student.getStudentEmail());
									q11.setParameter("phone", student.getStudentPhNumber());
									q11.setParameter("dob", student.getStudentDOB());
									q11.setParameter("class", student.getStudentClass());
									q11.setParameter("gender", student.getStudentGender());
									q11.setParameter("id", student.getStudentId());
									q11.executeUpdate();
								} else {
									throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
								}
							} else {
								throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
							}
						}
					} else {
						throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_STUDENT");
					}
				} else {
					throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_STUDENT");
				}
			}
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void updateStudentAddress(Integer studentId, Address address) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q1.setParameter(0, studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			Query q2 = session.createQuery(
					"UPDATE AddressEntity ae SET ae.houseNumber= :number, ae.sector= :sector, ae.city= :city, ae.state= :state, ae.pinCode= :pin WHERE ae.addressId= :id");
			q2.setParameter("number", address.getHouseNumber());
			q2.setParameter("sector", address.getSector());
			q2.setParameter("city", address.getCity());
			q2.setParameter("state", address.getState());
			q2.setParameter("pin", address.getPinCode());
			q2.setParameter("id", list1.get(0).getStudentAddress().getAddressId());
			q2.executeUpdate();
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void updateStudentParent(Integer studentId, Parent parent) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM ParentEntity pe WHERE pe.parentId= :id");
			q1.setParameter("id", parent.getParentId());
			@SuppressWarnings("unchecked")
			List<ParentEntity> list1 = q1.list();
			ParentEntity pe = list1.get(0);
			if (pe.getParentEmail().equals(parent.getParentEmail())) {
				if (pe.getParentPhNumber().equals(parent.getParentPhNumber())) {
					Query q2 = session.createQuery(
							"UPDATE ParentEntity pe SET pe.parentName= :name,pe.parentEmail= :email,pe.parentPhNumber= :phone WHERE pe.parentId= :id");
					q2.setParameter("name", parent.getParentName());
					q2.setParameter("email", parent.getParentEmail());
					q2.setParameter("phone", parent.getParentPhNumber());
					q2.setParameter("id", parent.getParentId());
					q2.executeUpdate();
				} else if (!pe.getParentPhNumber().equals(parent.getParentPhNumber())) {
					Query q3 = session.createQuery("FROM ParentEntity pe WHERE pe.parentPhNumber= :number");
					q3.setParameter("number", parent.getParentPhNumber());
					@SuppressWarnings("unchecked")
					List<ParentEntity> list2 = q3.list();
					if (list2.isEmpty()) {
						Query q4 = session.createQuery("FROM StudentEntity se WHERE se.studentPhNumber= :number");
						q4.setParameter("number", parent.getParentPhNumber());
						@SuppressWarnings("unchecked")
						List<ParentEntity> list3 = q4.list();
						if (list3.isEmpty()) {
							Query q5 = session.createQuery(
									"UPDATE ParentEntity pe SET pe.parentName= :name,pe.parentEmail= :email,pe.parentPhNumber= :phone WHERE pe.parentId= :id");
							q5.setParameter("name", parent.getParentName());
							q5.setParameter("email", parent.getParentEmail());
							q5.setParameter("phone", parent.getParentPhNumber());
							q5.setParameter("id", parent.getParentId());
							q5.executeUpdate();
						} else {
							throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
						}
					} else {
						throw new Exception("UserDAO.PHONE_NO_TO_OTHER_STUDENT");
					}
				}
			} else if (!pe.getParentEmail().equals(parent.getParentEmail())) {
				Query q6 = session.createQuery("FROM ParentEntity pe WHERE pe.parentEmail= :email");
				q6.setParameter("email", parent.getParentEmail());
				@SuppressWarnings("unchecked")
				List<ParentEntity> list4 = q6.list();
				if (list4.isEmpty()) {
					Query q7 = session.createQuery("FROM StudentEntity se WHERE se.studentEmail= :email");
					q7.setParameter("email", parent.getParentEmail());
					@SuppressWarnings("unchecked")
					List<ParentEntity> list5 = q7.list();
					if (list5.isEmpty()) {
						if (pe.getParentPhNumber().equals(parent.getParentPhNumber())) {
							Query q8 = session.createQuery(
									"UPDATE ParentEntity pe SET pe.parentName= :name,pe.parentEmail= :email,pe.parentPhNumber= :phone WHERE pe.parentId= :id");
							q8.setParameter("name", parent.getParentName());
							q8.setParameter("email", parent.getParentEmail());
							q8.setParameter("phone", parent.getParentPhNumber());
							q8.setParameter("id", parent.getParentId());
							q8.executeUpdate();
						} else if (!pe.getParentPhNumber().equals(parent.getParentPhNumber())) {
							Query q9 = session.createQuery("FROM ParentEntity pe WHERE pe.parentPhNumber= :number");
							q9.setParameter("number", parent.getParentPhNumber());
							@SuppressWarnings("unchecked")
							List<ParentEntity> list6 = q9.list();
							if (list6.isEmpty()) {
								Query q10 = session
										.createQuery("FROM StudentEntity se WHERE se.studentPhNumber= :number");
								q10.setParameter("number", parent.getParentPhNumber());
								@SuppressWarnings("unchecked")
								List<ParentEntity> list7 = q10.list();
								if (list7.isEmpty()) {
									Query q11 = session.createQuery(
											"UPDATE ParentEntity pe SET pe.parentName= :name,pe.parentEmail= :email,pe.parentPhNumber= :phone WHERE pe.parentId= :id");
									q11.setParameter("name", parent.getParentName());
									q11.setParameter("email", parent.getParentEmail());
									q11.setParameter("phone", parent.getParentPhNumber());
									q11.setParameter("id", parent.getParentId());
									q11.executeUpdate();
								} else {
									throw new Exception("UserDAO.PHONE_NO_TO_OTHER_PARENT");
								}
							} else {
								throw new Exception("UserDAO.PHONE_NO_TO_OTHER_PARENT");
							}
						}
					} else {
						throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_PARENT");
					}
				} else {
					throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_PARENT");
				}
			}
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public byte[] getStudentPicture(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		byte[] studentImage = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM StudentEntity se WHERE se.studentId= :id");
			q1.setParameter("id", studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			StudentEntity se = list1.get(0);
			studentImage = se.getStudentImage();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentImage;
	}

	@Override
	public void updateStudentPicture(Integer studentId, byte[] studentPicture) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("UPDATE StudentEntity se SET se.studentImage= :image WHERE se.studentId= :id");
			q1.setParameter("image", studentPicture);
			q1.setParameter("id", studentId);
			q1.executeUpdate();
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void deleteStudentPicture(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("UPDATE StudentEntity se SET se.studentImage= :image WHERE se.studentId= :id");
			q1.setParameter("image", null);
			q1.setParameter("id", studentId);
			q1.executeUpdate();
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void updateStudentFee(HashMap<Integer, Boolean> feesMap) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			for (Entry<Integer, Boolean> entry : feesMap.entrySet()) {
				Integer key = entry.getKey();
				Boolean value = entry.getValue();
				Query q1 = session
						.createQuery("UPDATE StudentEntity se SET se.studentFee= :fee WHERE se.studentId= :id");
				q1.setParameter("fee", value);
				q1.setParameter("id", key);
				q1.executeUpdate();
			}
			session.getTransaction().commit();
			if (session.isOpen() || session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void refreshFees() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateStudentAttendance(HashMap<Integer, Boolean> feesMap) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Attendance> getAllAttendance() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Message> getAllMessages() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
