package com.rmc.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="MESSAGE")
public class MessageEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MESSAGE_ID")
	private Integer messageId;
	@Column(name = "MESSAGE_CONTENT")
	private String messageContent;
	@Temporal(TemporalType.DATE)
	@Column(name = "MESSAGE_DATE")
	private Calendar messageDate;
	@Column(name = "STUDENT_ID")
	private Integer messageStudentId;
	@Column(name = "PARENT_ID")
	private Integer messageParentId;

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public String getMessageContent() {
		return messageContent;
	}

	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public Calendar getMessageDate() {
		return messageDate;
	}

	public void setMessageDate(Calendar messageDate) {
		this.messageDate = messageDate;
	}

	public Integer getMessageStudentId() {
		return messageStudentId;
	}

	public void setMessageStudentId(Integer messageStudentId) {
		this.messageStudentId = messageStudentId;
	}

	public Integer getMessageParentId() {
		return messageParentId;
	}

	public void setMessageParentId(Integer messageParentId) {
		this.messageParentId = messageParentId;
	}

}
