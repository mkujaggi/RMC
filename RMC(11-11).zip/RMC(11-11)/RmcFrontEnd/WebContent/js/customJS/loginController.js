app.controller("LoginController",['$scope','$http','$location','$cookies','$rootScope', function($scope,$http,$location,$cookies,$rootScope) {
			$scope.adminLoginForm = {};
			$scope.messageAdmin=null;
			$scope.flagForMessageAdmin=false;
			$scope.studentLoginForm = {};
			$scope.messageStudent=null;
			$scope.flagForMessageStudent=false;
			$scope.parentLoginForm = {};
			$scope.messageParent=null;
			$scope.flagForMessageParent=false;
			
			$scope.adminLogin = function() {
				try {
					var data = angular.toJson($scope.adminLoginForm);
					var responsePromise = $http.post(URI + "LoginAPI/Admin",data);
				} catch (err) {
					$scope.messageAdmin = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					if(dataFromServer!=null){
						localStorage.removeItem('AdminDetails');
						window.localStorage['AdminDetails'] = JSON.stringify(dataFromServer);
						$cookies.put("name",dataFromServer.adminId);
						$cookies.put("email",dataFromServer.adminEmail);
						$scope.flagForMessageAdmin=false;
						window.location="teacherDashboard.html";
					}
					else{
						$scope.flagForMessageAdmin=true;
						$scope.messageAdmin=dataFromServer.message;
					}
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.flagForMessageAdmin=true;
					$scope.messageAdmin = data;
				});
			}
			
			$scope.studentLogin = function() {
				try {
					var data = angular.toJson($scope.studentLoginForm);
					var responsePromise = $http.post(URI + "LoginAPI/Student",data);
				} catch (err) {
					$scope.messageStudent = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					if(dataFromServer!=null){
						$scope.flagForMessageStudent=false;
						window.location="studentDashboard.html";
					}
					else{
						$scope.flagForMessageStudent=true;
						$scope.messageStudent=dataFromServer.message;
					}
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.flagForMessageStudent=true;
					$scope.messageStudent = data;
				});
			}
			
			$scope.parentLogin = function() {
				try {
					var data = angular.toJson($scope.parentLoginForm);
					var responsePromise = $http.post(URI + "LoginAPI/Parent",data);
				} catch (err) {
					$scope.messageParent = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					if(dataFromServer!=null){
						$scope.flagForMessageParent=false;
						window.location="parentDashboard.html";
					}
					else{
						$scope.flagForMessageParent=true;
						$scope.messageParent=dataFromServer.message;
					}
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.flagForMessageParent=true;
					$scope.messageParent = data;
				});
			}
			
			$scope.disableAllMessageFlags=function(){
				$scope.flagForMessageAdmin=false;
				$scope.flagForMessageStudent=false;
				$scope.flagForMessageParent=false;
			}
		}]);