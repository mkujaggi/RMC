URI = "http://localhost:8080/rmc/api/";

/* This is the main module of the RMC Application */
var app = angular.module('rmc', [ 'ngRoute', 'ngMessages', 'naif.base64',
		'ngCookies' ]);

/* This is the Route Configuration of the RMC Application */
app.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		templateUrl : 'partials/teacher/home.html',
		controller : 'TeacherController'
	}).when('/addNewStudent', {
		templateUrl : 'partials/teacher/addNewStudent.html',
		controller : 'TeacherController'
	}).when('/showStudents', {
		templateUrl : 'partials/teacher/showStudents.html',
		controller : 'TeacherController'
	}).when('/updateStudent', {
		templateUrl : 'partials/teacher/updateStudent.html',
		controller : 'TeacherController'
	}).when('/oneStudent', {
		templateUrl : 'partials/teacher/oneStudentDetail.html',
		controller : 'TeacherController'
	}).when('/updateStudentParent', {
		templateUrl : 'partials/teacher/updateStudentParent.html',
		controller : 'TeacherController'
	}).when('/updateStudentAddress', {
		templateUrl : 'partials/teacher/updateStudentAddress.html',
		controller : 'TeacherController'
	}).when('/addNewTest', {
		templateUrl : 'partials/teacher/addNewTest.html',
		controller : 'TestController'
	}).when('/showTests', {
		templateUrl : 'partials/teacher/showTests.html',
		controller : 'TestController'
	}).when('/oneTestDetail', {
		templateUrl : 'partials/teacher/oneTestDetail.html',
		controller : 'TestController'
	}).when('/updateTest', {
		templateUrl : 'partials/teacher/updateTest.html',
		controller : 'TestController'
	}).otherwise({
		redirect : '/'
	});
} ]);