/**
 * @author Yashik Gulati <yashikgulati22@gmail.com>
 */

/* This is the Teacher Controller */
app.controller("TeacherController",['$scope','$rootScope','$http','$location', function($scope,$rootScope,$http,$location) {
	
	$scope.addNewStudentForm={};
	$scope.fee={};
	$scope.adminImage={};
	$scope.adminImageDecoded={};
	$scope.studentImage={};
	$scope.studentImageDecoded={};
	
	/* This method is used to add the new student details to the database */
	$scope.addNewStudent=function(){
		try {
			var data = angular.toJson($scope.addNewStudentForm);
			var responsePromise = $http.post(URI + "TeacherAPI/AddStudent",data);
		} catch (err) {
			$scope.messageForStudentAdd = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.messageForStudentAdd="New Student added with Student Id: "+dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForStudentAdd = data;
		});
	}
	
	/* This method fetches all the students from the database */
	$scope.getAllStudents = function() {
		$scope.flagForNoStudents=false;
		try {
			var responsePromise = $http.get(URI + "TeacherAPI/GetAllStudents");
		} catch (err) {
			$scope.messageForNoStudents = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flagForNoStudents=true;
			$scope.messageForNoStudents="No Students"
		});
	}
	
	/**
	 * The next three methods are for the filtering of the students based on
	 * class*
	 */
	/*
	 * This method is called when class 9 or class 10 is clicked on show
	 * students page, it receives a Class no according to which students will be
	 * filtered. It first gets all the students from the database then it
	 * filters them according to the class and duplicates it which will be used
	 * in filter students according to fees. Then it loads the data to the local
	 * storage for easy access and reloads the page.
	 */
	$scope.filterStudentsOnClass = function(Class) {
		$scope.flagForDelete=false;
		$scope.flagForNoStudents=false;
		$rootScope.StudentList=[];
		try {
			var responsePromise = $http.get(URI + "TeacherAPI/GetAllStudents");
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=dataFromServer;
			$scope.StudentsClass=Class;
			$scope.filteredStudentList=[];
			for (i = 0; i < $rootScope.StudentList.length; i++) {
				if($rootScope.StudentList[i].studentClass===Class){
					$scope.filteredStudentList.push($rootScope.StudentList[i])
				}
	        }
			$scope.tempStudentList=$scope.filteredStudentList;
			localStorage.removeItem('allStudents');
			localStorage.removeItem('StudentsClass');
			window.localStorage['allStudents'] = JSON.stringify($scope.filteredStudentList);
			window.localStorage['StudentsClass'] = JSON.stringify($scope.StudentsClass);
			if (window.localStorage.getItem('allStudents') != null){
				$scope.filteredStudentList = JSON.parse(window.localStorage['allStudents']);
				$scope.StudentsClass = JSON.parse(window.localStorage['StudentsClass']);
				$scope.tempStudentList=$scope.filteredStudentList;
			}
			location.reload();
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flagForNoStudents=true;
			$scope.messageForNoStudents="No Students"
		});
	}
	
	/*
	 * This method loads the local storage in the local variable when the page
	 * refreshes
	 */
	$scope.getLocalStorageForAllStudents=function(){
		$scope.filteredStudentList = JSON.parse(window.localStorage['allStudents']);
		$scope.StudentsClass = JSON.parse(window.localStorage['StudentsClass']);
		$scope.tempStudentList=$scope.filteredStudentList;
	}
	
	/*
	 * This method gets called on the teacher dash-board page and checks if
	 * there are students in the filtered list or if not then it shows proper
	 * error.
	 */
	$scope.onShowStudentsLoad=function(){
		$scope.flagForNoStudents=false;
		if($scope.filteredStudentList.length===0){
			$scope.flagForNoStudents=true;
			$scope.messageForNoStudents="No Students"
		}
	}
	/** Filter students based on class methods Finished* */
	
	/** The next five methods are used to update the student details* */
	
	$scope.toggleDropdown=function(){
		$scope.flagForDropdown=true;
	}
	
	/*
	 * This method creates the local storage of the particular student which is
	 * clicked and will be updated on the next page
	 */
	$scope.setGlobalStudent=function(Student){
		localStorage.removeItem('oneStudent');
		window.localStorage['oneStudent'] = JSON.stringify(Student);
	}
	
	/*
	 * This method loads the local storage in the variable so that the details
	 * can be updated in this page
	 */
	$scope.getGlobalStudent=function(){
		$scope.localStudent=JSON.parse(window.localStorage['oneStudent']);
	}
	
	/*
	 * This method is used to update the student details in the database also
	 * when updated it fetches all the details from the database so as to keep
	 * the updated details
	 */
	$scope.updateStudentDetails=function(){
		try{
			$scope.flagForStudentUpdate=false;
			var data =angular.toJson($scope.localStudent);
			var responsePromise = $http.put(URI + "TeacherAPI/UpdateStudent",data);
		}
		catch (err) {
			$scope.flagForStudentUpdate=true;
			$scope.messageForStudentUpdate = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=[];
			var responsePromise1 = $http.get(URI + "TeacherAPI/GetAllStudents");
			responsePromise1.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.StudentList=dataFromServer;
			});
			responsePromise1.error(function(data, status, headers,
					config) {
				$scope.flagForNoStudents=true;
				$scope.messageForNoStudents="No Students"
			});
			console.log(dataFromServer)
			$scope.messageForStudentUpdate=dataFromServer;
			$scope.flagForStudentUpdate=true;
			$scope.flagForDropdown=false;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flagForStudentUpdate=true;
			$scope.messageForStudentUpdate = data;
		});
	}
	
	/*
	 * This method is used to update the student parent details in the database
	 * also when updated it fetches all the details from the database so as to
	 * keep the updated details
	 */
	$scope.updateStudentParentDetails=function(){
		try{
			var data =angular.toJson($scope.localStudent);
			var responsePromise = $http.put(URI + "TeacherAPI/UpdateStudentParent",data);
		}
		catch (err) {
			$scope.messageForStudentParentUpdate = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=[];
			var responsePromise1 = $http.get(URI + "TeacherAPI/GetAllStudents");
			responsePromise1.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.StudentList=dataFromServer;
			});
			responsePromise1.error(function(data, status, headers,
					config) {
				$scope.flagForNoStudents=true;
				$scope.messageForNoStudents="No Students"
			});
			$scope.messageForStudentParentUpdate=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForStudentParentUpdate = data;
		});
	}
	
	/*
	 * This method is used to update the student address details in the database
	 * also when updated it fetches all the details from the database so as to
	 * keep the updated details
	 */
	$scope.updateStudentAddressDetails=function(){
		try{
			var data =angular.toJson($scope.localStudent);
			var responsePromise = $http.put(URI + "TeacherAPI/UpdateStudentAddress",data);
		}
		catch (err) {
			$scope.messageForStudentAddressUpdate = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=[];
			var responsePromise1 = $http.get(URI + "TeacherAPI/GetAllStudents");
			responsePromise1.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.StudentList=dataFromServer;
			});
			responsePromise1.error(function(data, status, headers,
					config) {
				$scope.flagForNoStudents=true;
				$scope.messageForNoStudents="No Students"
			});
			$scope.messageForStudentAddressUpdate=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForStudentAddressUpdate = data;
		});
	}
	/** Update Student methods Finished* */
	
	/** The next three methods are used to delete the student details* */
	/* This method sets the variable so the student can be deleted */
	$scope.setStudentForDelete=function(student){
		$scope.flagForDelete=false;
		$scope.tempStudentForDelete=student;
	}
	
	/*
	 * This method is called from the show students page where there are many
	 * students, it deletes the student from the database and then it calls the
	 * filter Student on class method also when deleted it fetches all the
	 * details from the database so as to keep the updated details
	 */
	$scope.deleteStudent=function(){
		try {
			var responsePromise = $http.delete(URI + "TeacherAPI/DeleteStudent/"+$scope.tempStudentForDelete.studentId);
		} catch (err) {
			$scope.messageAfterDelete = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.flagForDelete=true;
			$rootScope.StudentList=[];
			var responsePromise1 = $http.get(URI + "TeacherAPI/GetAllStudents");
			responsePromise1.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.StudentList=dataFromServer;
			});
			responsePromise1.error(function(data, status, headers,
					config) {
				$scope.flagForNoStudents=true;
				$scope.messageForNoStudents="No Students"
			});
			$scope.filterStudentsOnClass($scope.StudentsClass);
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageAfterDelete = data;
			$scope.flagForDelete=false;
		});
	}
	
	/*
	 * This method is called from the one student page where there is only one
	 * student detail, it deletes the student from the database and then it
	 * takes you back to the show students page and calls the filter Student on
	 * class method also when deleted it fetches all the details from the
	 * database so as to keep the updated details
	 */
	$scope.deleteStudentInterior=function(){
		try {
			var responsePromise = $http.delete(URI + "TeacherAPI/DeleteStudent/"+$scope.tempStudentForDelete.studentId);
		} catch (err) {
			$scope.messageAfterDelete = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=[];
			var responsePromise1 = $http.get(URI + "TeacherAPI/GetAllStudents");
			responsePromise1.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.StudentList=dataFromServer;
			});
			responsePromise1.error(function(data, status, headers,
					config) {
				$scope.flagForNoStudents=true;
				$scope.messageForNoStudents="No Students"
			});
			$location.path("/showStudents");
			$scope.filterStudentsOnClass($scope.StudentsClass);
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageAfterDelete = data;
			$scope.flagForDelete=false;
		});
	}
	/** Delete Student methods Finished* */
	
	/** The next three methods are used to update fees of the student details* */
	/*
	 * This method is only used for the show of the update fees button, it
	 * checks if the check-box are changed then it shows the update fees button
	 */
	$scope.showUpdateFeesButton=function(){
		$scope.flagForUpdateFees=false;
		var count=0;
		for (value in $scope.fee) {
			count+=1;
		}
		if(count>=1){
			$scope.flagForUpdateFees=true;
		}
	}
	
	/*
	 * This method updates the fees of the students in the database also when
	 * updated it fetches all the details from the database so as to keep the
	 * updated details
	 */
	$scope.updateFees=function(){
		var data =angular.toJson($scope.fee);
		try{
			var responsePromise = $http.put(URI + "TeacherAPI/UpdateFee",data);
		}
		catch (err) {
			$scope.messageForFeeUpdate = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.StudentList=[];
			var responsePromise1 = $http.get(URI + "TeacherAPI/GetAllStudents");
			responsePromise1.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.StudentList=dataFromServer;
			});
			responsePromise1.error(function(data, status, headers,
					config) {
				$scope.flagForNoStudents=true;
				$scope.messageForNoStudents="No Students"
			});
			$scope.messageForFeeUpdate=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForFeeUpdate = data;
		});
	}
	
	/*
	 * This method is used to filter students list based on whether they have
	 * given the fees or not
	 */
	$scope.filterStudentOnFees=function(data){
		$scope.flagForAllStudentsPaidFees=false;
		$scope.filteredStudentList=[];
		for (i = 0; i < $scope.tempStudentList.length; i++) {
			if(data==$scope.tempStudentList[i].studentFee){
				$scope.filteredStudentList.push($scope.tempStudentList[i])
			}
        }
		if($scope.filteredStudentList.length===0){
			$scope.flagForAllStudentsPaidFees=true;
			$scope.messageForAllStudentsPaidFees="No Students to show in this Category."
		}
	}
	/** Update Fees Student methods Finished* */
	
	/**
	 * The next six methods are for the admin image and the controls for the
	 * admin image*
	 */
	/*
	 * This methods gets the admin details from the index page and it loads
	 * admin image in the local storage for easy access
	 */
	$scope.getAdminDetails=function(){
		if(window.localStorage.getItem('AdminDetails') != null){
			$scope.onlyAdminDetails = JSON.parse(window.localStorage['AdminDetails']);
		}
		if(window.localStorage.getItem('AdminImage') != null){
			$scope.getOnlyAdminImage = JSON.parse(window.localStorage['AdminImage']);
			$scope.flagForDelete=true;
		}
	}
	
	/*
	 * This method shows the cancel and the upload button for the image if a new
	 * image has been selected from the computer
	 */
	$scope.adminImageChanged=function(){
		if($scope.adminImage!=null){
			$scope.flagForCancel=true;
			$scope.flagForUpload=true;
		}	
	}
	
	/*
	 * This method is triggered when the cancel button from the image controls
	 * is pressed it clears the image which was selected from the computer
	 */
	$scope.cancelAdminImageUpload=function(){
		$scope.adminImage=null
		$scope.flagForCancel=false;
		$scope.flagForUpload=false;
	}
	/*
	 * This method deletes the admin image from the database and then it
	 * disables the delete cancel and upload button as there is no image
	 * available also it clears the image in the local storage and then reloads
	 * the page
	 */
	$scope.deleteAdminImage = function(adminId) {
		$scope.getOnlyAdminImage={};
		try {
			var responsePromise = $http.delete(URI + "TeacherAPI/DeleteAdminImage/"+adminId);
		} catch (err) {
			$scope.messageForImageUpload = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.messageForImageUpload=dataFromServer;
			if(dataFromServer!=null){
				$scope.flagForDelete=false;
				$scope.flagForCancel=false;
				$scope.flagForUpload=false;
				localStorage.removeItem('AdminImage');
				location.reload();
			}
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForImageUpload="Error!!";
		});
	}
	
	/*
	 * This methods fetches the admin image from the database and then it
	 * enables the delete control and disables the upload and cancel button also
	 * it loads the local storage with the new image
	 */
	$scope.getAdminImage = function(adminId) {
		try {
			var responsePromise = $http.get(URI + "TeacherAPI/GetAdminImage/"+adminId);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.getOnlyAdminImage = dataFromServer
			if($scope.getOnlyAdminImage!=null){
				$scope.flagForDelete=true;
				$scope.flagForCancel=false;
				$scope.flagForUpload=false;
				localStorage.removeItem('AdminImage');
				window.localStorage['AdminImage'] = JSON.stringify($scope.getOnlyAdminImage);
			}
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message="Error!!";
		});
	}
	
	/*
	 * This method updates the admin image in the database and then it reloads
	 * the page
	 */
	$scope.updateAdminImage=function(){
		for(var key in $scope.adminImage) {
		    var value = $scope.adminImage[key];
		    $scope.adminImageDecoded.adminId=key
		    $scope.adminImageDecoded.adminImage=value.base64
		}
		var data =angular.toJson($scope.adminImageDecoded);
		try{
			var responsePromise = $http.put(URI + "TeacherAPI/UpdateAdminImage/",data);
		}
		catch (err) {
			$scope.messageForImageUpload = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.messageForImageUpload=dataFromServer;
			location.reload();
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForImageUpload = "Error!!";
		});
	}
	/** Admin Image methods Finished* */
	
	/**
	 * The next five methods are for the student image and the controls for the
	 * student image*
	 */
	/*
	 * This method shows the cancel and the upload button for the image if a new
	 * image has been selected from the computer
	 */
	$scope.studentImageChanged=function(){
		if($scope.studentImage!=null){
			$scope.flagForStudentCancel=true;
			$scope.flagForStudentUpload=true;
		}	
	}
	
	/*
	 * This method is triggered when the cancel button from the image controls
	 * is pressed it clears the image which was selected from the computer
	 */
	$scope.cancelStudentImageUpload=function(){
		$scope.studentImage=null
		$scope.flagForStudentCancel=false;
		$scope.flagForStudentUpload=false;
	}
	/*
	 * This method deletes the admin image from the database and then it
	 * disables the delete cancel and upload button as there is no image
	 * available also it clears the image in the local storage and then reloads
	 * the page
	 */
	$scope.deleteStudentImage = function(studentId) {
		$scope.getOnlyStudentImage={};
		try {
			var responsePromise = $http.delete(URI + "TeacherAPI/DeleteStudentImage/"+studentId);
		} catch (err) {
			$scope.messageForImageUpload = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.messageForImageUpload=dataFromServer;
			if(dataFromServer!=null){
				$scope.flagForStudentDelete=false;
				$scope.flagForStudentCancel=false;
				$scope.flagForStudentUpload=false;
				localStorage.removeItem('StudentImage');
				location.reload();
			}
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForImageUpload="Error!!";
		});
	}
	
	/*
	 * This methods fetches the student image from the database and then it
	 * enables the delete control and disables the upload and cancel button also
	 * it loads the local storage with the new image
	 */
	$scope.getStudentImage = function(studentId) {
		try {
			var responsePromise = $http.get(URI + "TeacherAPI/GetStudentImage/"+studentId);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.getOnlyStudentImage = dataFromServer
			if($scope.getOnlyStudentImage!=null){
				$scope.flagForStudentDelete=true;
				$scope.flagForStudentCancel=false;
				$scope.flagForStudentUpload=false;
				localStorage.removeItem('StudentImage');
				window.localStorage['StudentImage'] = JSON.stringify($scope.getOnlyStudentImage);
			}
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message="Error!!";
		});
	}
	
	/*
	 * This method updates the student image in the database and then it reloads
	 * the page
	 */
	$scope.updateStudentImage=function(){
		for(var key in $scope.studentImage) {
		    var value = $scope.studentImage[key];
		    $scope.studentImageDecoded.studentId=key
		    $scope.studentImageDecoded.studentImage=value.base64
		}
		var data =angular.toJson($scope.studentImageDecoded);
		try{
			var responsePromise = $http.put(URI + "TeacherAPI/UpdateStudentImage/",data);
		}
		catch (err) {
			$scope.messageForImageUpload = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.messageForImageUpload=dataFromServer;
			location.reload();
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForImageUpload = "Error!!";
		});
	}
	/** Student Image methods Finished* */
	
	/* This method generates a proper format of the Address */
	$scope.getAddress=function(){
		$scope.address="H.No. "+$scope.localStudent.studentAddress.houseNumber
		+", Sector "+$scope.localStudent.studentAddress.sector
		+", "+$scope.localStudent.studentAddress.city
		+", "+$scope.localStudent.studentAddress.state
		+", "+$scope.localStudent.studentAddress.pinCode;
	}
}])
