/**
 * @author Yashik Gulati <yashikgulati22@gmail.com>
 */

/* This is the Test Controller */
app.controller("TestController",['$scope','$rootScope','$http','$location', function($scope,$rootScope,$http,$location) {
	
	$scope.addNewTestForm={};
	$scope.testUpdateDate={};
	
	$scope.addNewTest=function(){
		try {
			var data = angular.toJson($scope.addNewTestForm);
			var responsePromise = $http.post(URI + "TestAPI/AddTest",data);
		} catch (err) {
			$scope.messageForTestAdd = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.messageForTestAdd="New test added with test Id: "+dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForTestAdd = data;
		});
	}
	
	$scope.getAllTests = function() {
		try {
			var responsePromise = $http.get(URI + "TestAPI/GetAllTests");
		} catch (err) {
			$scope.messageForNoTests = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$rootScope.allTestList=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.messageForNoTests = data;
		});
	}
	
	$scope.filterTestOnClass=function(Class){
		$scope.TestsClass=Class;
		$scope.filteredTestList=[];
		for (i = 0; i < $rootScope.allTestList.length; i++) {
			if($rootScope.allTestList[i].testClass===Class){
				$scope.filteredTestList.push($rootScope.allTestList[i])
			}
        }
		localStorage.removeItem('allTests');
		localStorage.removeItem('TestsClass');
		window.localStorage['allTests'] = JSON.stringify($scope.filteredTestList);
		window.localStorage['TestsClass'] = JSON.stringify($scope.TestsClass);
		if (window.localStorage.getItem('allTests') != null){
			$scope.filteredTestList = JSON.parse(window.localStorage['allTests']);
			$scope.TestsClass = JSON.parse(window.localStorage['TestsClass']);
		}
		location.reload();
	}
	
	$scope.getLocalStorageForAllTests=function(){
		$scope.filteredTestList = JSON.parse(window.localStorage['allTests']);
		$scope.TestsClass = JSON.parse(window.localStorage['TestsClass']);
	}
	
	$scope.setGlobalTest=function(Test){
		localStorage.removeItem('oneTest');
		window.localStorage['oneTest'] = JSON.stringify(Test);
	}
	
	$scope.getGlobalTest=function(){
		$scope.localTest=JSON.parse(window.localStorage['oneTest']);
		$scope.updatedDate=$scope.localTest.testDate.dayOfMonth+"-"+($scope.localTest.testDate.month+1)+"-"+$scope.localTest.testDate.year;
	}
	
	$scope.toggleDropdownClass=function(){
		$scope.flagForTestClassDropdown=true;
	}
	
	$scope.toggleDropdownDate=function(){
		$scope.flagForTestDateDropdown=true;
	}
	
	$scope.updateTestDetails=function(){
		try{
			if($scope.testUpdateDate.date!=undefined){
				$scope.localTest.testDate=$scope.testUpdateDate.date;
			}
			if($scope.testUpdateDate.date===undefined){
				$scope.localTest.testDate=$scope.localTest.testDate.year+"-"+$scope.localTest.testDate.month+1+"-"+$scope.localTest.testDate.dayOfMonth+"T18:30:00.000Z";
			}
			$scope.flagForTestUpdate=false;
			var data =angular.toJson($scope.localTest);
			console.log(data)
			var responsePromise = $http.put(URI + "TestAPI/UpdateTest",data);
		}
		catch (err) {
			$scope.flagForTestUpdate=true;
			$scope.messageForTestUpdate = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			try {
				var responsePromise = $http.get(URI + "TestAPI/GetAllTests");
			} catch (err) {
				$scope.messageForNoTests = "There is some system Issue, Please contact Administrator";
			}
			responsePromise.success(function(dataFromServer,
					status, headers, config) {
				$rootScope.allTestList=[]
				$rootScope.allTestList=dataFromServer;
				$scope.messageForTestUpdate=dataFromServer;
				$scope.flagForTestUpdate=true;
				$scope.flagForTestDateDropdown=false;
				$scope.flagForTestClassDropdown=false;
			});
			responsePromise.error(function(data, status, headers,
					config) {
				$scope.messageForNoTests = data;
			});
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flagForTestUpdate=true;
			$scope.messageForTestUpdate = data;
		});
	}
}])