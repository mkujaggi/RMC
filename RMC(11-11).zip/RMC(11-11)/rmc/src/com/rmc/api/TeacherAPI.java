package com.rmc.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.tomcat.util.codec.binary.Base64;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rmc.bean.Admin;
import com.rmc.bean.Student;
import com.rmc.business.service.TeacherService;
import com.rmc.resources.AppConfig;
import com.rmc.resources.Factory;

@Path("/TeacherAPI")
public class TeacherAPI {
	@POST
	@Path("/AddStudent")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addNewStudent(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		Integer studentId = null;
		Student student = gson.fromJson(dataRecieved, Student.class);
		TeacherService teacherService = Factory.createTeacherService();
		try {
			studentId = teacherService.addNewStudent(student);
			String value = gson.toJson(studentId);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("/GetAllStudents")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudentsByClass() {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		List<Student> list1 = new ArrayList<>();
		try {
			list1 = teacherService.getAllStudents();
			String value = gson.toJson(list1);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("GetAdminImage/{adminId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAdminImage(@PathParam("adminId") Integer adminId) {
		Gson gson = new Gson();
		Response returnValue = null;
		TeacherService teacherService = Factory.createTeacherService();
		try {
			byte[] image = teacherService.getAdminPicture(adminId);
			String value = Base64.encodeBase64String(image);
			String value1 = gson.toJson(value);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("GetStudentImage/{studentId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudentImage(@PathParam("studentId") Integer studentId) {
		Gson gson = new Gson();
		Response returnValue = null;
		TeacherService teacherService = Factory.createTeacherService();
		try {
			byte[] image = teacherService.getStudentPicture(studentId);
			String value = Base64.encodeBase64String(image);
			String value1 = gson.toJson(value);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateFee")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateFees(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		String value = dataRecieved;
		HashMap<Integer, Boolean> map = new Gson().fromJson(value, new TypeToken<HashMap<Integer, Boolean>>() {
		}.getType());
		TeacherService teacherService = Factory.createTeacherService();
		try {
			teacherService.updateStudentFee(map);
			String value2 = "Fees has been Updated";
			String value1 = gson.toJson(value2);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateStudent")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateStudent(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		Student student = gson.fromJson(dataRecieved, Student.class);
		try {
			teacherService.updateStudent(student);
			String successMessage = "Student's Details has been Updated";
			String value = gson.toJson(successMessage);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateStudentAddress")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateStudentAddress(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		Student student = gson.fromJson(dataRecieved, Student.class);
		try {
			teacherService.updateStudentAddress(student.getStudentId(), student.getStudentAddress());
			String successMessage = "Student's Address Details has been Updated";
			String value = gson.toJson(successMessage);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateStudentParent")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateStudentParent(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		Student student = gson.fromJson(dataRecieved, Student.class);
		try {
			teacherService.updateStudentParent(student.getStudentId(), student.getStudentParent());
			String successMessage = "Student's Parent Details has been Updated";
			String value = gson.toJson(successMessage);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateAdminImage")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response saveAdminImage(String dataRecieved) {
		Gson gson = new Gson();
		Response returnValue = null;
		String string = dataRecieved;
		Admin admin = new Admin();
		TeacherService teacherService = Factory.createTeacherService();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("adminImage")) {
				byte[] image = Base64.decodeBase64((String) value);
				admin.setAdminImage(image);
			}
			if (key.contains("adminId")) {
				value = ((String) value).substring(1, ((String) value).length() - 1);
				admin.setAdminId(Integer.parseInt((String) value));
			}
		}
		try {
			teacherService.updateAdminPicture(admin.getAdminId(), admin.getAdminImage());
			String value = "Photo Uploaded";
			String value1 = gson.toJson(value);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateStudentImage")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response saveStudentImage(String dataRecieved) {
		Gson gson = new Gson();
		Response returnValue = null;
		String string = dataRecieved;
		Student student = new Student();
		TeacherService teacherService = Factory.createTeacherService();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("studentImage")) {
				byte[] image = Base64.decodeBase64((String) value);
				student.setStudentImage(image);
			}
			if (key.contains("studentId")) {
				value = ((String) value).substring(1, ((String) value).length() - 1);
				student.setStudentId(Integer.parseInt((String) value));
			}
		}
		try {
			teacherService.updateStudentPicture(student.getStudentId(), student.getStudentImage());
			String value = "Photo Uploaded";
			String value1 = gson.toJson(value);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@DELETE
	@Path("/DeleteAdminImage/{adminId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteAdminImage(@PathParam("adminId") Integer adminId) {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		try {
			teacherService.deleteAdminPicture(adminId);
			String value1 = "Photo Deleted";
			String finalValue = gson.toJson(value1);
			returnValue = Response.ok(finalValue).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}

	@DELETE
	@Path("/DeleteStudentImage/{studentId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteStudentImage(@PathParam("studentId") Integer studentId) {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		try {
			teacherService.deleteStudentPicture(studentId);
			String value1 = "Photo Deleted";
			String finalValue = gson.toJson(value1);
			returnValue = Response.ok(finalValue).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}

	@DELETE
	@Path("/DeleteStudent/{studentId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteStudent(@PathParam("studentId") Integer studentId) {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherService teacherService = Factory.createTeacherService();
		try {
			String value = teacherService.deleteStudent(studentId);
			String value1 = "Student with name " + value + " has been Deleted. Please Refresh";
			String finalValue = gson.toJson(value1);
			returnValue = Response.ok(finalValue).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}
}