package com.rmc.api;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.rmc.bean.Test;
import com.rmc.business.service.TeacherTestService;
import com.rmc.resources.AppConfig;
import com.rmc.resources.Factory;

@Path("/TestAPI")
public class TestAPI {

	@POST
	@Path("/AddTest")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addNewTest(String dataRecieved) {
		Gson gson = new Gson();
		Response returnValue = null;
		String string = dataRecieved;
		Integer testId = null;
		Test test = new Test();
		TeacherTestService teacherTestService = Factory.createTeacherTestService();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("testName")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestName(valueTemp);
			}
			if (key.contains("testDescription")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestDescription(valueTemp);
			}
			if (key.contains("testDate")) {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy");
				Calendar cal = Calendar.getInstance();
				try {
					String valueTemp = (String) value;
					valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
					valueTemp = valueTemp.substring(0, valueTemp.indexOf("T"));
					cal.setTime(df1.parse(df1.format(df.parse(valueTemp))));
					cal.add(Calendar.DATE, 1);
				} catch (ParseException e) {
				}
				test.setTestDate(cal);
			}
			if (key.contains("testMarks")) {
				test.setTestMarks(Integer.parseInt((String) value));
			}
			if (key.contains("testClass")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestClass(Integer.parseInt((String) valueTemp));
			}
			if (key.contains("testTime")) {
				test.setTestTime(Integer.parseInt((String) value));
			}
		}
		try {
			testId = teacherTestService.addNewTest(test);
			String value = gson.toJson(testId);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("/GetAllTests")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTestByClass() {
		Response returnValue = null;
		Gson gson = new Gson();
		TeacherTestService teacherTestService = Factory.createTeacherTestService();
		List<Test> list1 = new ArrayList<>();
		try {
			list1 = teacherTestService.getAllTests();
			String value = gson.toJson(list1);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/UpdateTest")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateTest(String dataRecieved) {
		Gson gson = new Gson();
		Response returnValue = null;
		String string = dataRecieved;
		Test test = new Test();
		TeacherTestService teacherTestService = Factory.createTeacherTestService();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("testId")) {
				test.setTestId(Integer.parseInt((String) value));
			}
			if (key.contains("testName")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestName(valueTemp);
			}
			if (key.contains("testDescription")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestDescription(valueTemp);
			}
			if (key.contains("testDate")) {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy");
				Calendar cal = Calendar.getInstance();
				try {
					String valueTemp = (String) value;
					valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
					valueTemp = valueTemp.substring(0, valueTemp.indexOf("T"));
					cal.setTime(df1.parse(df1.format(df.parse(valueTemp))));
					cal.add(Calendar.DATE, 1);
				} catch (ParseException e) {
				}
				test.setTestDate(cal);
			}
			if (key.contains("testMarks")) {
				test.setTestMarks(Integer.parseInt((String) value));
			}
			if (key.contains("testTime")) {
				test.setTestTime(Integer.parseInt((String) value));
			}
			if (key.contains("testClass")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestClass(Integer.parseInt((String) valueTemp));
			}
		}
		try {
			teacherTestService.updateTest(test);
			String value1 = "Test Updated";
			String value = gson.toJson(value1);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}
}
