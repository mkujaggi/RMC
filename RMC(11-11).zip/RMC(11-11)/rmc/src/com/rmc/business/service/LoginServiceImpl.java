package com.rmc.business.service;

import org.apache.log4j.Logger;

import com.rmc.bean.Admin;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.dao.LoginDAO;
import com.rmc.resources.Factory;

public class LoginServiceImpl implements LoginService {

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public Admin getAdminDetails(String email, String password) throws Exception {
		try {
			LoginDAO loginDAO = Factory.createLoginDao();
			return loginDAO.getAdminDetails(email, password);
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public Student getStudentDetails(String email, String password) throws Exception {
		try {
			LoginDAO loginDAO = Factory.createLoginDao();
			return loginDAO.getStudentDetails(email, password);
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public Parent getParentDetails(String email, String password) throws Exception {
		try {
			LoginDAO loginDAO = Factory.createLoginDao();
			return loginDAO.getParentDetails(email, password);
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

}
