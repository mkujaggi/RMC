package com.rmc.business.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.rmc.bean.Test;
import com.rmc.bean.TestStudent;
import com.rmc.dao.TeacherTestDAO;
import com.rmc.resources.Factory;

public class TeacherTestServiceImpl implements TeacherTestService {

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public Integer addNewTest(Test test) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		Integer testId = null;
		try {
			testId = teacherTestDAO.addNewTest(test);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testId;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public List<Test> getAllTests() throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		List<Test> finalList = new ArrayList<>();
		try {
			finalList = teacherTestDAO.getAllTests();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return finalList;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public List<TestStudent> getAllTestsGiven() throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		List<TestStudent> finalList = new ArrayList<>();
		try {
			finalList = teacherTestDAO.getAllTestsGiven();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return finalList;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void deleteTest(Integer testId) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.deleteTest(testId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateTest(Test test) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.updateTest(test);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void addStudentMarks(HashMap<Integer, HashMap<Integer, Integer>> marksMap) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.addStudentMarks(marksMap);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudentMarks(HashMap<Integer, HashMap<Integer, Integer>> marksMap) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.updateStudentMarks(marksMap);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void deleteStudentFromTest(HashMap<Integer, HashMap<Integer, Boolean>> marksMap) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.deleteStudentFromTest(marksMap);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateAnswerSheet(Integer testId, Integer studentId, byte[] answerSheet) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.updateAnswerSheet(testId, studentId, answerSheet);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public byte[] getAnswerSheetForStudent(Integer testId, Integer studentId) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		byte[] finalImage = null;
		try {
			finalImage = teacherTestDAO.getAnswerSheetForStudent(testId, studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return finalImage;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public byte[] getQuestionPaper(Integer testId) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		byte[] finalImage = null;
		try {
			finalImage = teacherTestDAO.getQuestionPaper(testId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return finalImage;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void setQuestionPaper(Integer testId, byte[] questionPaper) throws Exception {
		TeacherTestDAO teacherTestDAO = Factory.createTeacherTestDao();
		try {
			teacherTestDAO.setQuestionPaper(testId, questionPaper);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}
}
