package com.rmc.dao;

import com.rmc.bean.Admin;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;

public interface LoginDAO {
	 public Admin getAdminDetails(String email, String password) throws Exception;

	 public Student getStudentDetails(String email, String password) throws Exception;

	 public Parent getParentDetails(String email, String password) throws Exception;
}
