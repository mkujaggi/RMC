package com.rmc.dao;

import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.bean.Admin;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.entity.AdminEntity;
import com.rmc.entity.ParentEntity;
import com.rmc.entity.StudentEntity;
import com.rmc.resources.HibernateUtility;

public class LoginDAOImpl implements LoginDAO {
	/*
	 * This method checks whether the Admin credentials are in the data base or
	 * not. It throws proper exceptions if there is some error
	 */
	@Override
	public Admin getAdminDetails(String email, String password) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Admin admin = null;
		try {
			session = sessionFactory.openSession();
			Query q1 = session.createQuery("FROM AdminEntity a WHERE a.adminEmail=?");
			q1.setParameter(0, email);
			@SuppressWarnings("unchecked")
			List<AdminEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("UserDAO.USERNAME_NOT_FOUND");
			} else if (!(list1.get(0).getAdminPassword().equals(password))) {
				throw new Exception("UserDAO.INVALID_PASSWORD");
			}
			admin = new Admin();
			admin.setAdminEmail(list1.get(0).getAdminEmail());
			admin.setAdminId(list1.get(0).getAdminId());
			if (session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return admin;
	}

	/*
	 * This method checks whether the Student credentials are in the data base
	 * or not. It throws proper exceptions if there is some error
	 */
	@Override
	public Student getStudentDetails(String email, String password) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Student student = null;
		try {
			session = sessionFactory.openSession();
			Query q1 = session.createQuery("FROM StudentEntity a WHERE a.studentEmail=?");
			q1.setParameter(0, email);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("UserDAO.USERNAME_NOT_FOUND");
			} else if (!(list1.get(0).getStudentPassword().equals(password))) {
				throw new Exception("UserDAO.INVALID_PASSWORD");
			}
			student = new Student();
			student.setStudentName(list1.get(0).getStudentName());
			student.setStudentId(list1.get(0).getStudentId());
			if (session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return student;
	}

	/*
	 * This method checks whether the Parent credentials are in the data base or
	 * not. It throws proper exceptions if there is some error. Also it updates
	 * the last login and no of times login of the parent
	 */
	@Override
	public Parent getParentDetails(String email, String password) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Parent parent = null;
		try {
			session = sessionFactory.openSession();
			Query q1 = session.createQuery("FROM ParentEntity a WHERE a.parentEmail=?");
			q1.setParameter(0, email);
			@SuppressWarnings("unchecked")
			List<ParentEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("UserDAO.USERNAME_NOT_FOUND");
			} else if (!(list1.get(0).getParentPassword().equals(password))) {
				throw new Exception("UserDAO.INVALID_PASSWORD");
			}
			Integer countLogin = list1.get(0).getParentTimesLogin();
			countLogin += 1;
			Calendar cal = Calendar.getInstance();
			Query q2 = session.createQuery(
					"UPDATE ParentEntity pe SET pe.parentTimesLogin= :count, pe.parentLastLogin= :date WHERE pe.parentId= :id");
			q2.setParameter("count", countLogin);
			q2.setParameter("date", cal);
			q2.setParameter("id", list1.get(0).getParentId());
			session.beginTransaction();
			q2.executeUpdate();
			session.getTransaction().commit();
			parent = new Parent();
			parent.setParentName(list1.get(0).getParentName());
			parent.setParentId(list1.get(0).getParentId());
			parent.setParentTimesLogin(countLogin);
			if (session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return parent;
	}
}
