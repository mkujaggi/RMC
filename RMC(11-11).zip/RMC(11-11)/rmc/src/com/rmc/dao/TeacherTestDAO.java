package com.rmc.dao;

import java.util.HashMap;
import java.util.List;

import com.rmc.bean.Test;
import com.rmc.bean.TestStudent;

public interface TeacherTestDAO {
	public Integer addNewTest(Test test) throws Exception;

	public List<Test> getAllTests() throws Exception;

	public List<TestStudent> getAllTestsGiven() throws Exception;

	public void deleteTest(Integer testId) throws Exception;

	public void updateTest(Test test) throws Exception;

	public void addStudentMarks(HashMap<Integer, HashMap<Integer, Integer>> marksMap) throws Exception;

	public void updateStudentMarks(HashMap<Integer, HashMap<Integer, Integer>> marksMap) throws Exception;

	public void deleteStudentFromTest(HashMap<Integer, HashMap<Integer, Boolean>> marksMap) throws Exception;

	public void updateAnswerSheet(Integer testId, Integer studentId, byte[] answerSheet) throws Exception;

	public byte[] getAnswerSheetForStudent(Integer testId, Integer studentId) throws Exception;

	public byte[] getQuestionPaper(Integer testId) throws Exception;

	public void setQuestionPaper(Integer testId, byte[] questionPaper) throws Exception;
}
