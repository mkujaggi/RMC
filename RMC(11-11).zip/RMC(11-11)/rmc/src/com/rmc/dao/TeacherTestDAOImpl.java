package com.rmc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.bean.Test;
import com.rmc.bean.TestStudent;
import com.rmc.entity.TestEntity;
import com.rmc.resources.HibernateUtility;

public class TeacherTestDAOImpl implements TeacherTestDAO {

	@Override
	public Integer addNewTest(Test test) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer testId = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			TestEntity te = new TestEntity();
			te.setTestClass(test.getTestClass());
			te.setTestDate(test.getTestDate());
			te.setTestDescription(test.getTestDescription());
			te.setTestMarks(test.getTestMarks());
			te.setTestName(test.getTestName());
			te.setTestTime(test.getTestTime());
			testId = (Integer) session.save(te);
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testId;
	}

	@Override
	public List<Test> getAllTests() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Test> testResult = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM TestEntity te");
			@SuppressWarnings("unchecked")
			List<TestEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("TestDAO.NO_TEST_IN_DATABASE");
			}
			for (TestEntity te : list1) {
				Test t = new Test();
				t.setTestClass(te.getTestClass());
				t.setTestDate(te.getTestDate());
				t.setTestDescription(te.getTestDescription());
				t.setTestId(te.getTestId());
				t.setTestMarks(te.getTestMarks());
				t.setTestName(te.getTestName());
				t.setTestTime(te.getTestTime());
				testResult.add(t);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testResult;
	}

	@Override
	public List<TestStudent> getAllTestsGiven() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTest(Integer testId) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateTest(Test test) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery(
					"UPDATE TestEntity te SET te.testName= :name,te.testDescription= :desc,te.testDate= :date,te.testMarks= :marks,te.testTime= :time,te.testClass= :class WHERE te.testId= :id");
			q1.setParameter("name", test.getTestName());
			q1.setParameter("desc", test.getTestDescription());
			q1.setParameter("date", test.getTestDate());
			q1.setParameter("marks", test.getTestMarks());
			q1.setParameter("time", test.getTestTime());
			q1.setParameter("class", test.getTestClass());
			q1.setParameter("id", test.getTestId());
			q1.executeUpdate();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void addStudentMarks(HashMap<Integer, HashMap<Integer, Integer>> marksMap) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateStudentMarks(HashMap<Integer, HashMap<Integer, Integer>> marksMap) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteStudentFromTest(HashMap<Integer, HashMap<Integer, Boolean>> marksMap) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAnswerSheet(Integer testId, Integer studentId, byte[] answerSheet) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public byte[] getAnswerSheetForStudent(Integer testId, Integer studentId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getQuestionPaper(Integer testId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setQuestionPaper(Integer testId, byte[] questionPaper) throws Exception {
		// TODO Auto-generated method stub

	}

}
