package com.rmc.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "ATTENDANCE")
public class AttendanceEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ATTENDANCE_ID")
	private Integer attendanceId;
	@Temporal(TemporalType.DATE)
	@Column(name = "ATTENDANCE_DATE")
	private Calendar attendanceDate;
	@Column(name = "STUDENT_ID")
	private Integer studentId;
	@Column(name = "ATTENDANCE_STATUS")
	private Boolean studentStatus;

	public Integer getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(Integer attendanceId) {
		this.attendanceId = attendanceId;
	}

	public Calendar getAttendanceDate() {
		return attendanceDate;
	}

	public void setAttendanceDate(Calendar attendanceDate) {
		this.attendanceDate = attendanceDate;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Boolean getStudentStatus() {
		return studentStatus;
	}

	public void setStudentStatus(Boolean studentStatus) {
		this.studentStatus = studentStatus;
	}

}
