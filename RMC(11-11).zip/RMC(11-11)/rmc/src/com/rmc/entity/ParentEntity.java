package com.rmc.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "PARENT")
public class ParentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PARENT_ID")
	private Integer parentId;
	@Column(name = "PARENT_NAME")
	private String parentName;
	@Column(name = "PARENT_EMAIL")
	private String parentEmail;
	@Column(name = "PARENT_PASSWORD")
	private String parentPassword;
	@Column(name = "PARENT_MOBILE_NO")
	private String parentPhNumber;
	@Column(name = "PARENT_TIMES_LOGIN")
	private Integer parentTimesLogin;
	@Temporal(TemporalType.DATE)
	@Column(name = "PARENT_LAST_LOGIN")
	private Calendar parentLastLogin;

	public String getParentPhNumber() {
		return parentPhNumber;
	}

	public void setParentPhNumber(String parentPhNumber) {
		this.parentPhNumber = parentPhNumber;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentEmail() {
		return parentEmail;
	}

	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public String getParentPassword() {
		return parentPassword;
	}

	public void setParentPassword(String parentPassword) {
		this.parentPassword = parentPassword;
	}

	public Integer getParentTimesLogin() {
		return parentTimesLogin;
	}

	public void setParentTimesLogin(Integer parentTimesLogin) {
		this.parentTimesLogin = parentTimesLogin;
	}

	public Calendar getParentLastLogin() {
		return parentLastLogin;
	}

	public void setParentLastLogin(Calendar parentLastLogin) {
		this.parentLastLogin = parentLastLogin;
	}

}
