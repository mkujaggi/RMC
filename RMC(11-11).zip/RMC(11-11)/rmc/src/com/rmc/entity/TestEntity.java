package com.rmc.entity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TEST")
public class TestEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TEST_ID")
	private Integer testId;
	@Column(name = "TEST_NAME")
	private String testName;
	@Column(name = "TEST_DESCRIPTION")
	private String testDescription;
	@Temporal(TemporalType.DATE)
	@Column(name = "TEST_DATE")
	private Calendar testDate;
	@Column(name = "TEST_MARKS")
	private Integer testMarks;
	@Column(name = "TEST_TIME")
	private Integer testTime;
	@Column(name = "TEST_CLASS")
	private Integer testClass;
	@Column(name = "TEST_QP")
	private byte[] testQP;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "TEST_STUDENT", joinColumns = { @JoinColumn(name = "TEST_ID") }, inverseJoinColumns = {
			@JoinColumn(name = "STUDENT_ID") })
	private List<StudentEntity> students = new ArrayList<>();

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getTestDescription() {
		return testDescription;
	}

	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}

	public Calendar getTestDate() {
		return testDate;
	}

	public void setTestDate(Calendar testDate) {
		this.testDate = testDate;
	}

	public Integer getTestMarks() {
		return testMarks;
	}

	public void setTestMarks(Integer testMarks) {
		this.testMarks = testMarks;
	}

	public Integer getTestTime() {
		return testTime;
	}

	public void setTestTime(Integer testTime) {
		this.testTime = testTime;
	}

	public Integer getTestClass() {
		return testClass;
	}

	public void setTestClass(Integer testClass) {
		this.testClass = testClass;
	}

	public List<StudentEntity> getStudents() {
		return students;
	}

	public void setStudents(List<StudentEntity> students) {
		this.students = students;
	}

	public byte[] getTestQP() {
		return testQP;
	}

	public void setTestQP(byte[] testQP) {
		this.testQP = testQP;
	}

}
