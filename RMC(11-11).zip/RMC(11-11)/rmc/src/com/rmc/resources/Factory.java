package com.rmc.resources;

import com.rmc.business.service.LoginService;
import com.rmc.business.service.LoginServiceImpl;
import com.rmc.business.service.TeacherService;
import com.rmc.business.service.TeacherServiceImpl;
import com.rmc.business.service.TeacherTestService;
import com.rmc.business.service.TeacherTestServiceImpl;
import com.rmc.dao.LoginDAO;
import com.rmc.dao.LoginDAOImpl;
import com.rmc.dao.TeacherDAO;
import com.rmc.dao.TeacherDAOImpl;
import com.rmc.dao.TeacherTestDAO;
import com.rmc.dao.TeacherTestDAOImpl;

public class Factory {
	public static LoginDAO createLoginDao() {
		return new LoginDAOImpl();
	}

	public static LoginService createLoginService() {
		return new LoginServiceImpl();
	}

	public static TeacherDAO createTeacherDao() {
		return new TeacherDAOImpl();
	}

	public static TeacherService createTeacherService() {
		return new TeacherServiceImpl();
	}

	public static TeacherTestDAO createTeacherTestDao() {
		return new TeacherTestDAOImpl();
	}

	public static TeacherTestService createTeacherTestService() {
		return new TeacherTestServiceImpl();
	}
}
