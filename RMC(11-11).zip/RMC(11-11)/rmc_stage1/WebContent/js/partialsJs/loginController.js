app.controller("LoginController",['$scope','$http','$location', function($scope,$http,$location) {
			$scope.adminLoginForm = {};
			$scope.message=null;
			$scope.adminLoginForm.getAdminDetails = function() {
				try {
					var data = angular.toJson($scope.adminLoginForm);
					var responsePromise = $http.post(URI + "LoginAPI",data);
				} catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					if(dataFromServer!=null){
						window.location="\eacherChoice.html";
					}
					else{
						$scope.message=dataFromServer.message;
					}
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
		}]);