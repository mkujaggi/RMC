URI = "http://localhost:8080/rmc_stage1/api/";

var app = angular.module('rmc', [ 'ngRoute', 'ngMessages', 'naif.base64' ])
app.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/allStudents', {
		templateUrl : 'partials/teacher/showAllStudents.html',
		controller : 'TeacherController'
	}).when('/addStudents', {
		templateUrl : 'partials/teacher/addNewStudent.html',
		controller : 'TeacherController'
	}).when('/oneStudentDetail', {
		templateUrl : 'partials/teacher/oneStudentDetail.html',
		controller : 'TeacherController'
	}).when('/updateStudent', {
		templateUrl : 'partials/teacher/updateStudent.html',
		controller : 'TeacherController'
	}).when('/updateStudentParent', {
		templateUrl : 'partials/teacher/updateStudentParent.html',
		controller : 'TeacherController'
	}).when('/updateStudentAddress', {
		templateUrl : 'partials/teacher/updateStudentAddress.html',
		controller : 'TeacherController'
	}).when('/addTests', {
		templateUrl : 'partials/teacher/addNewTest.html',
		controller : 'TestController'
	}).when('/allTests', {
		templateUrl : 'partials/teacher/showAllTest.html',
		controller : 'TestController'
	}).when('/oneTestDetail', {
		templateUrl : 'partials/teacher/oneTestDetail.html',
		controller : 'TestController'
	}).when('/updateTest', {
		templateUrl : 'partials/teacher/updateTest.html',
		controller : 'TestController'
	}).when('/addStudentsToTest', {
		templateUrl : 'partials/teacher/addStudentsToTest.html',
		controller : 'TestController'
	}).when('/showStudentsForTests', {
		templateUrl : 'partials/teacher/showStudentsForTests.html',
		controller : 'TestController'
	})
} ]);
