package com.rmc.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.rmc.business.service.FeeService;
import com.rmc.resources.AppConfig;
import com.rmc.resources.Factory;

@Path("/FeeAPI")
public class FeeAPI {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response refreshFee() {
		Response returnValue = null;
		Gson gson = new Gson();
		FeeService feeService = Factory.createFeeService();
		String data = null;
		try {
			data = feeService.refreshFee();
			String value = gson.toJson(data);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("/feeManually")
	@Produces(MediaType.APPLICATION_JSON)
	public Response refreshFeeManually() {
		Response returnValue = null;
		Gson gson = new Gson();
		FeeService feeService = Factory.createFeeService();
		String data = null;
		try {
			data = feeService.refreshFeeManually();
			String value = gson.toJson(data);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}
}
