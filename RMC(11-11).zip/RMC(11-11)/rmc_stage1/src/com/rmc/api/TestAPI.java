package com.rmc.api;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rmc.bean.Student;
import com.rmc.bean.Test;
import com.rmc.business.service.TestService;
import com.rmc.resources.AppConfig;
import com.rmc.resources.Factory;

@Path("/TestAPI")
public class TestAPI {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addNewTest1(String dataRecieved) {
		Gson gson = new Gson();
		Response returnValue = null;
		String string = dataRecieved;
		Integer testId = null;
		Test test = new Test();
		TestService testService = Factory.createTestService();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("testName")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestName(valueTemp);
			}
			if (key.contains("testDescription")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestDescription(valueTemp);
			}
			if (key.contains("testDate")) {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy");
				Calendar cal = Calendar.getInstance();
				try {
					String valueTemp = (String) value;
					valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
					valueTemp = valueTemp.substring(0, valueTemp.indexOf("T"));
					cal.setTime(df1.parse(df1.format(df.parse(valueTemp))));
					cal.add(Calendar.DATE, 1);
				} catch (ParseException e) {
				}
				test.setTestDate(cal);
			}
			if (key.contains("testMarks")) {
				test.setTestMarks(Integer.parseInt((String) value));
			}
			if (key.contains("testTime")) {
				test.setTestTime(Integer.parseInt((String) value));
			}
			if (key.contains("testClass")) {
				test.setTestClass(Integer.parseInt((String) value));
			}
		}
		try {
			testId = testService.addNewTest(test);
			String value = gson.toJson(testId);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("testByClass/{classNo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTestByClass(@PathParam("classNo") Integer classNo) {
		Response returnValue = null;
		Gson gson = new Gson();
		TestService testService = Factory.createTestService();
		List<Test> list1 = new ArrayList<>();
		try {
			list1 = testService.getTestByClass(classNo);
			String value = gson.toJson(list1);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("getStudentsGivenTest/{testId}/{testClass}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudentsGivenTest(@PathParam("testId") Integer testId,
			@PathParam("testClass") Integer testClass) {
		Response returnValue = null;
		Gson gson = new Gson();
		TestService testService = Factory.createTestService();
		List<Student> list1 = new ArrayList<>();
		try {
			list1 = testService.getStudentsGivenTest(testId, testClass);
			String value = gson.toJson(list1);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("getStudentsByMarks/{testId}/{value}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudentsByMarks(@PathParam("testId") Integer testId, @PathParam("value") Boolean value) {
		Response returnValue = null;
		Gson gson = new Gson();
		TestService testService = Factory.createTestService();
		List<Student> list1 = new ArrayList<>();
		try {
			list1 = testService.getStudentsByMarks(testId, value);
			String value1 = gson.toJson(list1);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value1 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value1).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value1).build();
			}
		}
		return returnValue;
	}

	@GET
	@Path("testById/{testId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTestById(@PathParam("testId") Integer testId) {
		Response returnValue = null;
		Gson gson = new Gson();
		TestService testService = Factory.createTestService();
		List<Student> list2 = new ArrayList<>();
		try {
			list2 = testService.getMarksForTest(testId);
			String value = gson.toJson(list2);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateTest(String dataRecieved) {
		Gson gson = new Gson();
		Response returnValue = null;
		String string = dataRecieved;
		Integer testId = null;
		Test test = new Test();
		TestService testService = Factory.createTestService();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("testId")) {
				test.setTestId(Integer.parseInt((String) value));
			}
			if (key.contains("testName")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestName(valueTemp);
			}
			if (key.contains("testDescription")) {
				String valueTemp = (String) value;
				valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
				test.setTestDescription(valueTemp);
			}
			if (key.contains("testDate")) {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy");
				Calendar cal = Calendar.getInstance();
				try {
					String valueTemp = (String) value;
					valueTemp = valueTemp.substring(1, valueTemp.length() - 1);
					valueTemp = valueTemp.substring(0, valueTemp.indexOf("T"));
					cal.setTime(df1.parse(df1.format(df.parse(valueTemp))));
					cal.add(Calendar.DATE, 1);
				} catch (ParseException e) {
				}
				test.setTestDate(cal);
			}
			if (key.contains("testMarks")) {
				test.setTestMarks(Integer.parseInt((String) value));
			}
			if (key.contains("testTime")) {
				test.setTestTime(Integer.parseInt((String) value));
			}
			if (key.contains("testClass")) {
				test.setTestClass(Integer.parseInt((String) value));
			}
		}
		try {
			testId = testService.updateTest(test);
			String value = gson.toJson(testId);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/updateMarks")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateMarks(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		String value = dataRecieved;
		HashMap<String, HashMap<String, Integer>> map = new Gson().fromJson(value,
				new TypeToken<HashMap<String, HashMap<String, Integer>>>() {
				}.getType());
		TestService testService = Factory.createTestService();
		try {
			testService.updateMarks(map);
			String value2 = "Marks has been Added";
			String value1 = gson.toJson(value2);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/updateStudentMarks")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateStudentMarks(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		String value = dataRecieved;
		HashMap<String, HashMap<String, Integer>> map = new Gson().fromJson(value,
				new TypeToken<HashMap<String, HashMap<String, Integer>>>() {
				}.getType());
		TestService testService = Factory.createTestService();
		try {
			testService.updateStudentMarks(map);
			String value2 = "Marks has been Updated";
			String value1 = gson.toJson(value2);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}

	@PUT
	@Path("/deleteStudentsFromTest")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteStudentFromTest(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		String value = dataRecieved;
		HashMap<String, HashMap<String, Boolean>> map = new Gson().fromJson(value,
				new TypeToken<HashMap<String, HashMap<String, Boolean>>>() {
				}.getType());
		TestService testService = Factory.createTestService();
		try {
			testService.deleteStudentFromTest(map);
			String value2 = "Students have been deleted from this test";
			String value1 = gson.toJson(value2);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}

	@DELETE
	@Path("/{testId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteTest(@PathParam("testId") Integer testId) {
		Response returnValue = null;
		Gson gson = new Gson();
		TestService testService = Factory.createTestService();
		try {
			String value = testService.deleteTest(testId);
			String value1 = gson.toJson(value);
			returnValue = Response.ok(value1).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value3 = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE).entity(value3).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value3).build();
			}
		}
		return returnValue;
	}
}
