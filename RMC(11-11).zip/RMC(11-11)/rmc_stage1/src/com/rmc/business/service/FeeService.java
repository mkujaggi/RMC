package com.rmc.business.service;

public interface FeeService {
	public String refreshFee() throws Exception;

	public String refreshFeeManually() throws Exception;
}
