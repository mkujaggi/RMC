package com.rmc.business.service;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.rmc.dao.FeeDAO;
import com.rmc.resources.Factory;

public class FeeServiceImpl implements FeeService {

	@Override
	public String refreshFee() throws Exception {
		Calendar today = Calendar.getInstance();
		String value = null;
		FeeDAO feeDAO = Factory.createFeeDAO();
		try {
			if (today.get(Calendar.DAY_OF_MONTH) >= 1
					&& today.get(Calendar.DAY_OF_MONTH) <= 2) {
				value = "Fees of all students will be refreshed on 5th of "
						+ today.get(Calendar.MONTH)
						+ " Please check the previos fees.";
			} else if (today.get(Calendar.DAY_OF_MONTH) == 3) {
				value = "Fees will be refreshed on 5th, Please collect from unpaid students";
			} else if (today.get(Calendar.DAY_OF_MONTH) == 4) {
				value = "Fees will be refreshed tomorrow, Collect Unpaid fees for previous month";
			} else if (today.get(Calendar.DAY_OF_MONTH) == 5) {
				feeDAO.refreshFee();
				value = "Fees has been refreshed for all students";
			}
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return value;
	}

	@Override
	public String refreshFeeManually() throws Exception {
		String value = null;
		FeeDAO feeDAO = Factory.createFeeDAO();
		try {
			feeDAO.refreshFee();
			value = "Fees has been refreshed for all students. Click close";
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return value;
	}
}
