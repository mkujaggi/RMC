package com.rmc.business.service;

public interface SendSMSService {
	public String sendSms(String userMessage, String number) throws Exception;
}
