package com.rmc.business.service;

import org.apache.log4j.Logger;

import com.rmc.resources.Factory;
import com.rmc.sms.SendSMS;

public class SendSMSServiceImpl implements SendSMSService {

	@Override
	public String sendSms(String userMessage, String number) throws Exception {
		try {
			String value = null;
			SendSMS sendSMS = Factory.createSendSMS();
			value = sendSMS.sendSms(userMessage, number);
			return value;
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception);
			throw exception;
		}
	}

}
