package com.rmc.business.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.rmc.bean.Address;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.business.validator.StudentValidator;
import com.rmc.dao.StudentDAO;
import com.rmc.resources.Factory;

public class StudentServiceImpl implements StudentService {

	@Override
	public Integer addNewStudent(Student student) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		StudentValidator validator = Factory.createValidator();
		Integer studentId = null;
		try {
			validator.validateStudent(student);
			studentId = studentDAO.addNewStudent(student);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentId;
	}

	@Override
	public List<Student> getStudentsByClass(Integer classNo) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		List<Student> studentList = new ArrayList<>();
		try {
			studentList = studentDAO.getStudentsByClass(classNo);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentList;
	}

	@Override
	public List<Student> getStudentsByFee(Integer stuClass, Boolean value)
			throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		List<Student> studentList = new ArrayList<>();
		try {
			studentList = studentDAO.getStudentsByFee(stuClass, value);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentList;
	}

	@Override
	public Student getStudentById(Integer studentId) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		Student student = new Student();
		try {
			student = studentDAO.getStudentById(studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return student;
	}

	@Override
	public String deleteStudent(Integer studentId) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		String studName = null;
		try {
			studName = studentDAO.deleteStudent(studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studName;

	}

	@Override
	public Integer updatStudent(Student student) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		StudentValidator validator = Factory.createValidator();
		Integer id = null;
		try {
			if (validator.isValidEmail(student.getStudentEmail())) {
				if (validator.isValidPhoneNumber(student.getStudentPhNumber())) {
					id = studentDAO.updatStudent(student);
				} else {
					throw new Exception("Validator.INVALID_STUDENT_PHONE");
				}
			} else {
				throw new Exception("Validator.INVALID_STUDENT_EMAIL");
			}
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return id;
	}

	@Override
	public void updatStudentAddress(Integer studentId, Address address)
			throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		StudentValidator validator = Factory.createValidator();
		try {
			if (validator.isValidPincode(address.getPinCode())) {
				studentDAO.updatStudentAddress(studentId, address);
			} else {
				throw new Exception("Validator.INVALID_PINCODE");
			}
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}

	}

	@Override
	public void updatStudentParent(Integer studentId, Parent parent)
			throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		StudentValidator validator = Factory.createValidator();
		try {
			if (validator.isValidEmail(parent.getParentEmail())) {
				if (validator.isValidPhoneNumber(parent.getParentPhNumber())) {
					studentDAO.updatStudentParent(studentId, parent);
				} else {
					throw new Exception("Validator.INVALID_PARENT_PHONE");
				}
			} else {
				throw new Exception("Validator.INVALID_PARENT_EMAIL");
			}
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}

	}

	@Override
	public void updatStudentFees(HashMap<String, String> map) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		try {
			studentDAO.updatStudentFees(map);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void savePicture(Integer studentId, byte[] image) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		try {
			System.out.println("in service");
			studentDAO.savePicture(studentId, image);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public byte[] getPicture(Integer studentId) throws Exception {
		StudentDAO studentDAO = Factory.createStudentDAO();
		byte[] image = null;
		try {
			image = studentDAO.getPicture(studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return image;
	}
}
