package com.rmc.business.service;

import java.util.HashMap;
import java.util.List;

import com.rmc.bean.Student;
import com.rmc.bean.Test;

public interface TestService {
	public Integer addNewTest(Test test) throws Exception;

	public List<Test> getTestByClass(Integer classNo) throws Exception;

	public Test getTestById(Integer testId) throws Exception;

	public String deleteTest(Integer testId) throws Exception;

	public Integer updateTest(Test test) throws Exception;

	public void updateMarks(HashMap<String, HashMap<String, Integer>> map) throws Exception;

	public List<Student> getMarksForTest(Integer testId) throws Exception;

	public void updateStudentMarks(HashMap<String, HashMap<String, Integer>> map) throws Exception;

	public void deleteStudentFromTest(HashMap<String, HashMap<String, Boolean>> map) throws Exception;

	public List<Student> getStudentsGivenTest(Integer testId, Integer testClass) throws Exception;

	public List<Student> getStudentsByMarks(Integer testId, Boolean value) throws Exception;
}
