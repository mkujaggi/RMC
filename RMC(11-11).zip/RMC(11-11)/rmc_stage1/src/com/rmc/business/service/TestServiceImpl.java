package com.rmc.business.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.rmc.bean.Student;
import com.rmc.bean.Test;
import com.rmc.dao.TestDAO;
import com.rmc.resources.Factory;

public class TestServiceImpl implements TestService {

	@Override
	public Integer addNewTest(Test test) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		Integer testId = null;
		try {
			testId = testDAO.addNewTest(test);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testId;
	}

	@Override
	public List<Test> getTestByClass(Integer classNo) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		List<Test> testList = new ArrayList<>();
		try {
			testList = testDAO.getTestByClass(classNo);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testList;
	}

	@Override
	public Test getTestById(Integer testId) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		Test test = new Test();
		try {
			test = testDAO.getTestById(testId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return test;
	}

	@Override
	public List<Student> getStudentsByMarks(Integer testId, Boolean value)
			throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		List<Student> list2 = new ArrayList<>();
		try {
			list2 = testDAO.getStudentsByMarks(testId, value);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return list2;
	}

	@Override
	public List<Student> getStudentsGivenTest(Integer testId, Integer testClass)
			throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		List<Student> list2 = new ArrayList<>();
		try {
			list2 = testDAO.getStudentsGivenTest(testId, testClass);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return list2;
	}

	@Override
	public List<Student> getMarksForTest(Integer testId) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		List<Student> list2 = new ArrayList<>();
		try {
			list2 = testDAO.getMarksForTest(testId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return list2;
	}

	@Override
	public String deleteTest(Integer testId) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		String testName = null;
		try {
			testName = testDAO.deleteTest(testId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testName;
	}

	@Override
	public Integer updateTest(Test test) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		Integer testId = null;
		try {
			testId = testDAO.updatTest(test);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testId;
	}

	@Override
	public void updateMarks(HashMap<String, HashMap<String, Integer>> map)
			throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		try {
			testDAO.updateMarks(map);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void updateStudentMarks(HashMap<String, HashMap<String, Integer>> map)
			throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		try {
			testDAO.updateStudentMarks(map);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void deleteStudentFromTest(
			HashMap<String, HashMap<String, Boolean>> map) throws Exception {
		TestDAO testDAO = Factory.createTestDAO();
		try {
			testDAO.deleteStudentFromTest(map);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

}
