package com.rmc.dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.resources.HibernateUtility;

public class FeeDAOImpl implements FeeDAO {

	@Override
	public void refreshFee() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("UPDATE StudentEntity se SET se.studentFee= :fee");
			q1.setParameter("fee", false);
			q1.executeUpdate();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}
}
