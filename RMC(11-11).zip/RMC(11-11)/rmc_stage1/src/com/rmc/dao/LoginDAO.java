package com.rmc.dao;

import com.rmc.bean.Admin;

public interface LoginDAO {
	Admin getAdminDetails(String email, String password) throws Exception;
}
