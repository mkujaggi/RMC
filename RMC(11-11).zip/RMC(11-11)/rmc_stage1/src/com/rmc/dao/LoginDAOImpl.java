package com.rmc.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.bean.Admin;
import com.rmc.entity.AdminEntity;
import com.rmc.resources.HibernateUtility;

public class LoginDAOImpl implements LoginDAO {

	@Override
	public Admin getAdminDetails(String email, String password) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Admin a1 = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session.createQuery("FROM AdminEntity a WHERE a.adminEmail=?");
			q1.setParameter(0, email);
			@SuppressWarnings("unchecked")
			List<AdminEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("UserDAO.USERNAME_NOT_FOUND");
			} else if (!(list1.get(0).getAdminPassword().equals(password))) {
				throw new Exception("UserDAO.INVALID_PASSWORD");
			}
			a1 = new Admin();
			a1.setAdminEmail(list1.get(0).getAdminEmail());
			a1.setAdminId(list1.get(0).getAdminId());
			session.getTransaction().commit();
			if (session != null) {
				session.close();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return a1;
	}

}
