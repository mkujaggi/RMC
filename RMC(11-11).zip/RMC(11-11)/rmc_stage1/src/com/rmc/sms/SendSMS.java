package com.rmc.sms;

public interface SendSMS {
	public String sendSms(String userMessage, String number) throws Exception;
}
