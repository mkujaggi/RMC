package com.rmc.sms;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class SendSMSImpl implements SendSMS {
	private static final String userName = "yashikgulati22@gmail.com";
	private static final String hashCode = "a87889d9e293a264b394adeb3aa8fc7ca50465b7";

	@Override
	public String sendSms(String userMessage, String number) throws Exception {
		try {
			userMessage = userMessage.substring(1, userMessage.length() - 1);
			// Construct data
			String user = "username=" + userName;
			String hash = "&hash=" + hashCode;
			String message = "&message=" + userMessage;
			String sender = "&sender=" + "TXTLCL";
			String numbers = "&numbers=" + number;

			// Send data
			HttpURLConnection conn = (HttpURLConnection) new URL(
					"http://api.textlocal.in/send/?").openConnection();
			String data = user + hash + numbers + message + sender;
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Length",
					Integer.toString(data.length()));
			conn.getOutputStream().write(data.getBytes("UTF-8"));
			final BufferedReader rd = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			final StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}
			rd.close();
			return stringBuffer.toString();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception);
			throw exception;
		}
	}

}
