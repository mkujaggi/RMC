package com.rmc.test;

import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import com.rmc.bean.Address;
import com.rmc.bean.Admin;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.bean.Test;
import com.rmc.business.service.FeeService;
import com.rmc.business.service.LoginService;
import com.rmc.business.service.StudentService;
import com.rmc.business.service.TestService;
import com.rmc.resources.AppConfig;
import com.rmc.resources.Factory;
import com.rmc.resources.HibernateUtility;

public class UserInterface {
	private static LoginService loginService = Factory.createLoginService();
	private static StudentService studentService = Factory.createStudentService();
	private static TestService testService = Factory.createTestService();
	private static FeeService feeService = Factory.createFeeService();

	public static void main(String[] args) {
		try {
			// userLogin();

			// addNewStudent();
			// findStudentsByClass();
			// deleteStudent();
			// updateStudent();
			// getStudentById();
			// updateStudentAddress();
			// updateStudentParent();
			// updateStudentFee();

			// addNewTest();
			// getTestByClass();
			// getTestById();
			// updateTest();
			// deleteTest();
			// updateMarks();
			// getMarksForTest();
			// updateStudentMarks();
			// deleteStudentFromTest();
			// getStudentsGivenTest();
			getStudentsByMarks();

			// refreshFee();
		} finally {
			HibernateUtility.closeSessionFactory();
		}
	}

	public static void userLogin() {
		try {
			Admin admin = loginService.getAdminDetails("yashik@gmail.com", "123456");
			System.out.println("Admin with User Email as: " + admin.getAdminEmail() + " has successfully logged in.");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void addNewStudent() {
		try {
			Address a = new Address();
			a.setCity("Mysore");
			a.setHouseNumber("G1");
			a.setPinCode(570002);
			a.setSector("Adipumpa Road");
			a.setState("Karnataka");
			Parent p = new Parent();
			p.setParentEmail("mukul@gmail.com");
			p.setParentName("Mukul");
			p.setParentPassword("mukul123");
			p.setParentPhNumber("7896541239");
			Student s = new Student();
			s.setStudentAddress(a);
			s.setStudentParent(p);
			s.setStudentClass(10);
			s.setStudentDOB("1992-22-25");
			s.setStudentEmail("kashish@gmail.com");
			s.setStudentFee(false);
			s.setStudentGender('M');
			s.setStudentName("Kashish");
			s.setStudentPassword("kashish123");
			s.setStudentPhNumber("1236547899");
			Integer studentId = studentService.addNewStudent(s);
			System.out.println("Student adden with Student ID: " + studentId + " and with name " + s.getStudentName());
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void findStudentsByClass() {
		try {
			List<Student> list1 = studentService.getStudentsByClass(9);
			for (Student s : list1) {
				System.out.println("Student name is " + s.getStudentName() + " and parent is "
						+ s.getStudentParent().getParentName());
			}
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteStudent() {
		try {
			String id = studentService.deleteStudent(220101);
			System.out.println("Student Deleted with name: " + id);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateStudent() {
		try {
			Student s1 = new Student();
			s1.setStudentId(220101);
			s1.setStudentName("Yashik");
			s1.setStudentPhNumber("9874563212");
			s1.setStudentClass(10);
			s1.setStudentDOB("1992-02-19");
			s1.setStudentEmail("asmit@gmail.com");
			Integer id = studentService.updatStudent(s1);
			System.out.println("Student updated with studen id: " + id);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getStudentById() {
		try {
			Student s1 = new Student();
			s1 = studentService.getStudentById(220101);
			System.out
					.println("Student " + s1.getStudentName() + " has parent " + s1.getStudentParent().getParentName());
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateStudentAddress() {
		try {
			Address a1 = new Address();
			a1.setCity("Delhi");
			a1.setHouseNumber("258ghdfgh");
			a1.setPinCode(1234654);
			a1.setSector("munic");
			a1.setState("delhi");
			studentService.updatStudentAddress(220101, a1);
			System.out.println("Student Updated");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateStudentParent() {
		try {
			Parent p1 = new Parent();
			p1.setParentEmail("kanwal@gmail.com");
			p1.setParentName("Parveen");
			p1.setParentPhNumber("3214565575");
			studentService.updatStudentParent(220101, p1);
			System.out.println("Parent Updated");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateStudentFee() {
		try {
			HashMap<String, String> data = new HashMap<String, String>();
			data.put("220101", "true");
			data.put("220102", "true");
			data.put("220103", "true");
			data.put("220104", "true");
			studentService.updatStudentFees(data);
			System.out.println("Fee Updated");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void addNewTest() {
		Test test = new Test();
		test.setTestClass(10);
		test.setTestDate(new GregorianCalendar(1997, 10, 6));
		test.setTestDescription("do test");
		test.setTestMarks(100);
		test.setTestTime(3);
		test.setTestName("Numbers");
		try {
			Integer testId = testService.addNewTest(test);
			System.out.println("new test added with id: " + testId);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getTestByClass() {
		try {
			List<Test> testList = testService.getTestByClass(9);
			for (Test test : testList) {
				System.out.println("test Name is " + test.getTestName());
			}
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getTestById() {
		Test t1 = new Test();
		try {
			t1 = testService.getTestById(11);
			System.out.println("test name is " + t1.getTestName());
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateTest() {
		Test test = new Test();
		test.setTestId(10);
		test.setTestClass(10);
		test.setTestDate(new GregorianCalendar(1997, 11, 12));
		test.setTestDescription("New Test update");
		test.setTestMarks(50);
		test.setTestTime(2);
		test.setTestName("Integers update");
		try {
			Integer testId = testService.updateTest(test);
			System.out.println("new test updated with id: " + testId);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteTest() {
		try {
			String s1 = testService.deleteTest(10);
			System.out.println("test deleted with name " + s1);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateMarks() {
		try {
			HashMap<String, Integer> mapObject = new HashMap<String, Integer>();
			HashMap<String, HashMap<String, Integer>> map = new HashMap<String, HashMap<String, Integer>>();
			mapObject.put("220101", 90);
			mapObject.put("220102", 45);
			mapObject.put("220103", 21);
			mapObject.put("220104", 21);
			map.put("10", mapObject);
			testService.updateMarks(map);
			System.out.println("Marks Added");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateStudentMarks() {
		try {
			HashMap<String, Integer> mapObject = new HashMap<String, Integer>();
			HashMap<String, HashMap<String, Integer>> map = new HashMap<String, HashMap<String, Integer>>();
			mapObject.put("220101", null);
			mapObject.put("220102", 50);
			mapObject.put("220103", 50);
			mapObject.put("220104", 35);
			map.put("10", mapObject);
			testService.updateStudentMarks(map);
			System.out.println("Marks Updated");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteStudentFromTest() {
		try {
			HashMap<String, Boolean> mapObject = new HashMap<String, Boolean>();
			HashMap<String, HashMap<String, Boolean>> map = new HashMap<String, HashMap<String, Boolean>>();
			mapObject.put("220101", false);
			mapObject.put("220104", true);
			map.put("10", mapObject);
			testService.deleteStudentFromTest(map);
			System.out.println("Students Deleted From test");
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getMarksForTest() {
		try {
			List<Student> list2 = testService.getMarksForTest(10);
			for (Student student : list2) {
				System.out.println(
						"Student name is " + student.getStudentName() + " and marks are " + student.getStudentMarks());
			}
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getStudentsGivenTest() {
		try {
			List<Student> list2 = testService.getStudentsGivenTest(10, 10);
			for (Student student : list2) {
				System.out.println(
						"Student name is " + student.getStudentName() + " and Id is " + student.getStudentId());
			}
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getStudentsByMarks() {
		try {
			List<Student> list2 = testService.getStudentsByMarks(10, true);
			for (Student student : list2) {
				System.out.println(
						"Student name is " + student.getStudentName() + " and marks are " + student.getStudentMarks());
			}
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void refreshFee() {
		try {
			String value = feeService.refreshFee();
			System.out.println(value);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
}
