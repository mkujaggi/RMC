/*This filter is used for the dates and it returns Not Seen if date is null else it returns a proper date*/
app.filter('CalendarFilter',
		function() {
			return function(dateValue) {
				if (dateValue == null) {
					return "Not Seen";
				} else {
					var month = dateValue.month;
					var monthStr = null;
					if (month == 0)
						monthStr = 'Jan';
					if (month == 1)
						monthStr = 'Feb';
					if (month == 2)
						monthStr = 'Mar';
					if (month == 3)
						monthStr = 'Apr';
					if (month == 4)
						monthStr = 'May';
					if (month == 5)
						monthStr = 'Jun';
					if (month == 6)
						monthStr = 'Jul';
					if (month == 7)
						monthStr = 'Aug';
					if (month == 8)
						monthStr = 'Sep';
					if (month == 9)
						monthStr = 'Oct';
					if (month == 10)
						monthStr = 'Nov';
					if (month == 11)
						monthStr = 'Dec';
					return dateValue.dayOfMonth + "-" + monthStr + "-"
							+ dateValue.year;

				}
			}
		});

/* This filter is used to display a proper text based on the times login */
app.filter('TimesLoginFilter', function() {
	return function(Value) {
		if (Value == 0 || Value == null) {
			return "Not Loggen In";
		}
		if (Value != 0) {
			return Value + " Times Login";
		}
	}
});

/* This filter is used to display a proper text based on the Student Class */
app.filter('StudentClassFilter', function() {
	return function(value) {
		if (value == 9)
			return 'Class 9';
		else if (value == 10)
			return 'Class 10';
	}
});

/* This filter is used to display a proper text based on the Student Gender */
app.filter('StudentGenderFilter', function() {
	return function(value) {
		if (value == 'M')
			return 'Male';
		else if (value == 'F')
			return 'Female';
	}
});

/* This filter is used to display a proper text based on the Student Fees */
app.filter('StudentFeeFilter', function() {
	return function(value) {
		if (value == true)
			return 'Paid';
		else if (value == false)
			return 'Not Paid';
	}
});

/* This filter is used for the dates and it returns a proper date */
app.filter('DOBFilter', function() {
	return function(dateValue) {
		var data = dateValue.split("-")
		var year = data[0];
		var month = data[1];
		if (month == 01)
			monthStr = 'Jan';
		if (month == 02)
			monthStr = 'Feb';
		if (month == 03)
			monthStr = 'Mar';
		if (month == 04)
			monthStr = 'Apr';
		if (month == 05)
			monthStr = 'May';
		if (month == 06)
			monthStr = 'Jun';
		if (month == 07)
			monthStr = 'Jul';
		if (month == 08)
			monthStr = 'Aug';
		if (month == 09)
			monthStr = 'Sep';
		if (month == 10)
			monthStr = 'Oct';
		if (month == 11)
			monthStr = 'Nov';
		if (month == 12)
			monthStr = 'Dec';
		var day = data[2];
		return day + "-" + monthStr + "-" + year;
	}
});