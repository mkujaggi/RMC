package com.rmc.bean;

import java.util.List;

public class Student {
	private Integer studentId;
	private String studentName;
	private String studentEmail;
	private String studentPassword;
	private String studentPhNumber;
	private String studentDOB;
	private Integer studentClass;
	private Character studentGender;
	private Boolean studentFee;
	private Address studentAddress;
	private Parent studentParent;
	private List<Test> studentTests;
	private Integer studentMarks;
	private byte[] studentImage;

	public byte[] getStudentImage() {
		return studentImage;
	}

	public void setStudentImage(byte[] studentImage) {
		this.studentImage = studentImage;
	}

	public Integer getStudentMarks() {
		return studentMarks;
	}

	public void setStudentMarks(Integer studentMarks) {
		this.studentMarks = studentMarks;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getStudentPhNumber() {
		return studentPhNumber;
	}

	public void setStudentPhNumber(String studentPhNumber) {
		this.studentPhNumber = studentPhNumber;
	}

	public String getStudentDOB() {
		return studentDOB;
	}

	public void setStudentDOB(String studentDOB) {
		this.studentDOB = studentDOB;
	}

	public Integer getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(Integer studentClass) {
		this.studentClass = studentClass;
	}

	public Character getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(Character studentGender) {
		this.studentGender = studentGender;
	}

	public Boolean getStudentFee() {
		return studentFee;
	}

	public void setStudentFee(Boolean studentFee) {
		this.studentFee = studentFee;
	}

	public Address getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(Address studentAddress) {
		this.studentAddress = studentAddress;
	}

	public Parent getStudentParent() {
		return studentParent;
	}

	public void setStudentParent(Parent studentParent) {
		this.studentParent = studentParent;
	}

	public List<Test> getStudentTests() {
		return studentTests;
	}

	public void setStudentTests(List<Test> studentTests) {
		this.studentTests = studentTests;
	}

}
