package com.rmc.bean;

import java.util.Calendar;
import java.util.List;

public class Test {
	private Integer testId;
	private String testName;
	private String testDescription;
	private Calendar testDate;
	private Integer testMarks;
	private Integer testTime;
	private Integer testClass;
	private List<Student> students;
	private byte[] testQP;

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getTestDescription() {
		return testDescription;
	}

	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}

	public Calendar getTestDate() {
		return testDate;
	}

	public void setTestDate(Calendar testDate) {
		this.testDate = testDate;
	}

	public Integer getTestMarks() {
		return testMarks;
	}

	public void setTestMarks(Integer testMarks) {
		this.testMarks = testMarks;
	}

	public Integer getTestTime() {
		return testTime;
	}

	public void setTestTime(Integer testTime) {
		this.testTime = testTime;
	}

	public Integer getTestClass() {
		return testClass;
	}

	public void setTestClass(Integer testClass) {
		this.testClass = testClass;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public byte[] getTestQP() {
		return testQP;
	}

	public void setTestQP(byte[] testQP) {
		this.testQP = testQP;
	}

}
