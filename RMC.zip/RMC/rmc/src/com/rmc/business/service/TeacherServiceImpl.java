package com.rmc.business.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.rmc.bean.Address;
import com.rmc.bean.Attendance;
import com.rmc.bean.Message;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.dao.TeacherDAO;
import com.rmc.resources.Factory;

public class TeacherServiceImpl implements TeacherService {
	
	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public Integer addNewStudent(Student student) throws Exception {
		TeacherDAO teacherDAO = Factory.createTeacherDao();
		Integer studentId = null;
		try {
			studentId = teacherDAO.addNewStudent(student);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentId;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public List<Student> getAllStudents() throws Exception {
		List<Student> finalList = new ArrayList<>();
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			finalList = teacherDAO.getAllStudents();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return finalList;
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public byte[] getAdminPicture(Integer adminId) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			return teacherDAO.getAdminPicture(adminId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateAdminPicture(Integer adminId, byte[] adminPicture) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateAdminPicture(adminId, adminPicture);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void deleteAdminPicture(Integer adminId) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.deleteAdminPicture(adminId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public String deleteStudent(Integer studentId) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			return teacherDAO.deleteStudent(studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudent(Student student) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateStudent(student);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudentAddress(Integer studentId, Address address) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateStudentAddress(studentId, address);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudentParent(Integer studentId, Parent parent) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateStudentParent(studentId, parent);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public byte[] getStudentPicture(Integer studentId) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			return teacherDAO.getStudentPicture(studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudentPicture(Integer studentId, byte[] studentPicture) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateStudentPicture(studentId, studentPicture);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void deleteStudentPicture(Integer studentId) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.deleteStudentPicture(studentId);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudentFee(HashMap<Integer, Boolean> feesMap) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateStudentFee(feesMap);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void refreshFees() throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.refreshFees();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}

	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public void updateStudentAttendance(HashMap<Integer, Boolean> feesMap) throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			teacherDAO.updateStudentAttendance(feesMap);
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}

	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public List<Attendance> getAllAttendance() throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			return teacherDAO.getAllAttendance();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	/*
	 * This method calls the appropriate method in the DAO class and re-throws
	 * the exception
	 */
	@Override
	public List<Message> getAllMessages() throws Exception {
		try {
			TeacherDAO teacherDAO = Factory.createTeacherDao();
			return teacherDAO.getAllMessages();
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}
}
