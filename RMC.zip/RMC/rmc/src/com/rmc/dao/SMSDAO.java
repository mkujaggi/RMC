package com.rmc.dao;

public interface SMSDAO {
	public String smsToParent(String message, String phoneNo) throws Exception;

	public String smsToAllParents(String message, String phoneNo) throws Exception;

	public String smsToStudent(String message, String phoneNo) throws Exception;

	public String smsToAllStudents(String message, String phoneNo) throws Exception;
}
