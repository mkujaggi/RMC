package com.rmc.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class StudentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "STUDENT_ID")
	private Integer studentId;
	@Column(name = "STUDENT_NAME")
	private String studentName;
	@Column(name = "STUDENT_EMAIL")
	private String studentEmail;
	@Column(name = "STUDENT_PASSWORD")
	private String studentPassword;
	@Column(name = "STUDENT_MOBILE_NO")
	private String studentPhNumber;
	@Column(name = "STUDENT_DOB")
	private String studentDOB;
	@Column(name = "STUDENT_CLASS")
	private Integer studentClass;
	@Column(name = "STUDENT_GENDER")
	private Character studentGender;
	@Column(name = "STUDENT_FEE")
	private Boolean studentFee;
	@Column(name = "STUDENT_IMAGE")
	private byte[] studentImage;
	public byte[] getStudentImage() {
		return studentImage;
	}

	public void setStudentImage(byte[] studentImage) {
		this.studentImage = studentImage;
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "STUDENT_ADDRESS_ID", unique = true)
	private AddressEntity studentAddress;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "STUDENT_PARENT_ID", unique = true)
	private ParentEntity studentParent;

	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "students")
	private List<TestEntity> studentTests = new ArrayList<>();

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getStudentPhNumber() {
		return studentPhNumber;
	}

	public void setStudentPhNumber(String studentPhNumber) {
		this.studentPhNumber = studentPhNumber;
	}

	public String getStudentDOB() {
		return studentDOB;
	}

	public void setStudentDOB(String studentDOB) {
		this.studentDOB = studentDOB;
	}

	public Integer getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(Integer studentClass) {
		this.studentClass = studentClass;
	}

	public Character getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(Character studentGender) {
		this.studentGender = studentGender;
	}

	public Boolean getStudentFee() {
		return studentFee;
	}

	public void setStudentFee(Boolean studentFee) {
		this.studentFee = studentFee;
	}

	public AddressEntity getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(AddressEntity studentAddress) {
		this.studentAddress = studentAddress;
	}

	public ParentEntity getStudentParent() {
		return studentParent;
	}

	public void setStudentParent(ParentEntity studentParent) {
		this.studentParent = studentParent;
	}

	public List<TestEntity> getStudentTests() {
		return studentTests;
	}

	public void setStudentTests(List<TestEntity> studentTests) {
		this.studentTests = studentTests;
	}

}
