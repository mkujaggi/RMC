package com.rmc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "TEST_STUDENT")
public class TestStudentEntity implements Serializable {
	@Id
	@Column(name = "TEST_ID")
	private Integer testId;
	@Id
	@Column(name = "STUDENT_ID")
	private Integer studentId;
	@Column(name = "STUDENT_MARKS")
	private Integer marksObtained;
	@Column(name = "STUDENT_ANSWER_SHEET")
	private byte[] answerSheet;

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(Integer marksObtained) {
		this.marksObtained = marksObtained;
	}

	public byte[] getAnswerSheet() {
		return answerSheet;
	}

	public void setAnswerSheet(byte[] answerSheet) {
		this.answerSheet = answerSheet;
	}

}
