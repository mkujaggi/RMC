package com.rmc.resources;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtility {

	private static final String CONFIGURATION_LOCATION="com/rmc/resources/hibernate.cfg.xml";
	private static SessionFactory sessionFactory=getSessionFactory();

	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			// loads configuration and mappings
			Configuration configuration = new Configuration().configure(CONFIGURATION_LOCATION);
			ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
					.applySettings(configuration.getProperties()).build();

			// builds a session factory from the service registry
			sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		}

		return sessionFactory;
	}
	public static SessionFactory createSessionFactory(){
		return getSessionFactory();
	}
	public static void closeSessionFactory(){
		if(!sessionFactory.isClosed()){
			sessionFactory.close();
		}
	}
}
