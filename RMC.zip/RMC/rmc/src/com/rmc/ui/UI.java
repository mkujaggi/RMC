package com.rmc.ui;

import com.rmc.bean.Admin;
import com.rmc.dao.LoginDAOImpl;
import com.rmc.resources.AppConfig;

public class UI {

	public static void main(String[] args) {
		LoginDAOImpl l1 = new LoginDAOImpl();
		try {
			Admin a1 = l1.getAdminDetails("yashik@gmail.com", "123456");
			System.out.println("Login successful " + a1.getAdminEmail());
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
}
