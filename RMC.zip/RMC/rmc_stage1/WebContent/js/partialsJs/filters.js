app.filter('StudentClassFilter', function() {
	return function(value) {
		if (value == 9)
			return 'Class 9';
		else if (value == 10)
			return 'Class 10';
	}
});

app.filter('StudentGenderFilter', function() {
	return function(value) {
		if (value == 'M')
			return 'Male';
		else if (value == 'F')
			return 'Female';
	}
});

app.filter('StudentFeeFilter', function() {
	return function(value) {
		if (value == true)
			return 'Paid';
		else if (value == false)
			return 'Not Paid';
	}
});

app.filter('StudentPhoneFilter', function() {
	return function(value) {
		var srt = "+91-" + value;
		return srt;
	}
});

app.filter('CalendarFilter', function() {
	return function(dateValue) {
		var data = dateValue.split("-");
		return data;
	}
});