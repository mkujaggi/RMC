var student={};
var stuClass=null;

app.controller("TeacherController",['$scope','$http', function($scope,$http) {
	
			$scope.userList = {};
			$scope.addUserList={};
			$scope.getStudent={};
			$scope.updateStudent={};
			$scope.getStudentClass=null;
			$scope.address=null;
			$scope.fee={};
			$scope.image = {};
			$scope.getStudentImage={};
			$scope.imageDecoded={};
			$scope.flag=false;
			$scope.flag1=false;
			$scope.flag2=false;
			$scope.flag3=false;
			$scope.message=null;
			
			$scope.getStudentsById = function(classId) {
				try {
					var responsePromise = $http.get(URI + "StudentAPI/studentByClass/"+classId);
				} catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.flag1=false;
					$scope.flag=true;
					$scope.flag3=false;
					$scope.userList=dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.flag=false;
					$scope.flag3=true;
					$scope.message = data;
				});
			}
			
			$scope.getStudentsByFees = function(stuClass,value) {
				try {
					var responsePromise = $http.get(URI + "StudentAPI/studentByFee/"+stuClass+"/"+value);
				} catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.flag1=false;
					$scope.flag=true;
					$scope.flag3=false;
					$scope.userList=dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.flag=false;
					$scope.flag3=true;
					$scope.message = data;
				});
			}
			
			$scope.addNewStudent=function(){
				try {
					var data = angular.toJson($scope.addUserList);
					var responsePromise = $http.post(URI + "StudentAPI",data);
				} catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.message="New User adde with user id "+dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			
			$scope.updateFees=function(){
				var data =angular.toJson($scope.fee);
				try{
					var responsePromise = $http.put(URI + "StudentAPI",data);
				}
				catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.flag1=true;
					$scope.message=dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			
			$scope.updateStudentImage=function(){
				for(var key in $scope.image) {
				    var value = $scope.image[key];
				    $scope.imageDecoded.studentId=key
				    $scope.imageDecoded.studentImage=value.base64
				}
				var data =angular.toJson($scope.imageDecoded);
				try{
					var responsePromise = $http.put(URI + "StudentAPI/studentImage/",data);
				}
				catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.message=dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			$scope.getImage = function(studentId) {
				try {
					var responsePromise = $http.get(URI + "StudentAPI/getImage/"+studentId);
				} catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.getStudentImage=dataFromServer;
					
				});
				responsePromise.error(function(data, status, headers,
						config) {
				});
			}
			
			$scope.updateStudentDetails=function(){
				$scope.updateStudent.studentId=$scope.getStudent.studentId;
				if($scope.updateStudent.studentName==null){
					$scope.updateStudent.studentName=$scope.getStudent.studentName;
				}
				if($scope.updateStudent.studentEmail==null){
					$scope.updateStudent.studentEmail=$scope.getStudent.studentEmail;
				}
				if($scope.updateStudent.studentPhNumber==null){
					$scope.updateStudent.studentPhNumber=$scope.getStudent.studentPhNumber;
				}
				if($scope.updateStudent.studentDOB==null){
					$scope.updateStudent.studentDOB=$scope.getStudent.studentDOB;
				}
				try{
					var data =angular.toJson($scope.updateStudent);
					var responsePromise = $http.put(URI + "StudentAPI/updateStudent",data);
				}
				catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.message="Student with ID: "+dataFromServer+" has been Updated";
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			
			$scope.updateStudentAddress=function(){
				if($scope.updateStudent.studentAddress==null){
					$scope.message = "Please do some Changes and then try again";
				}
				else{
					$scope.updateStudent.studentId=$scope.getStudent.studentId;
					if($scope.updateStudent.studentAddress.houseNumber==null){
						$scope.updateStudent.studentAddress.houseNumber=$scope.getStudent.studentAddress.houseNumber;
					}
					if($scope.updateStudent.studentAddress.sector==null){
						$scope.updateStudent.studentAddress.sector=$scope.getStudent.studentAddress.sector;
					}
					if($scope.updateStudent.studentAddress.city==null){
						$scope.updateStudent.studentAddress.city=$scope.getStudent.studentAddress.city;
					}
					if($scope.updateStudent.studentAddress.state==null){
						$scope.updateStudent.studentAddress.state=$scope.getStudent.studentAddress.state;
					}
					if($scope.updateStudent.studentAddress.pinCode==null){
						$scope.updateStudent.studentAddress.pinCode=$scope.getStudent.studentAddress.pinCode;
					}
					try{
						var data =angular.toJson($scope.updateStudent);
						var responsePromise = $http.put(URI + "StudentAPI/updateStudentAddress",data);
					}
					catch (err) {
						$scope.message = "There is some system Issue, Please contact Administrator";
					}
					responsePromise.success(function(dataFromServer,
							status, headers, config) {
						$scope.message="Address has been updated for student with ID: "+$scope.updateStudent.studentId;
					});
					responsePromise.error(function(data, status, headers,
							config) {
						$scope.message = data;
					});
				}
			}
			
			$scope.updateStudentParent=function(){
				if($scope.updateStudent.studentParent==null){
					$scope.message = "Please do some Changes and then try again";
				}
				else{
					$scope.updateStudent.studentId=$scope.getStudent.studentId;
					if($scope.updateStudent.studentParent.parentName==null){
						$scope.updateStudent.studentParent.parentName=$scope.getStudent.studentParent.parentName;
					}
					if($scope.updateStudent.studentParent.parentEmail==null){
						$scope.updateStudent.studentParent.parentEmail=$scope.getStudent.studentParent.parentEmail;
					}
					if($scope.updateStudent.studentParent.parentPhNumber==null){
						$scope.updateStudent.studentParent.parentPhNumber=$scope.getStudent.studentParent.parentPhNumber;
					}
					try{
						var data =angular.toJson($scope.updateStudent);
						var responsePromise = $http.put(URI + "StudentAPI/updateStudentParent",data);
					}
					catch (err) {
						$scope.message = "There is some system Issue, Please contact Administrator";
					}
					responsePromise.success(function(dataFromServer,
							status, headers, config) {
						$scope.message="Parent has been updated for student with ID: "+$scope.updateStudent.studentId;
					});
					responsePromise.error(function(data, status, headers,
							config) {
						$scope.message = data;
					});
				}
			}
			
			$scope.deleteStudent=function(studentId){
				try {
					var responsePromise = $http.delete(URI + "StudentAPI/"+studentId);
				} catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					$scope.message = "Student with name "+dataFromServer+" has been deleted. Close and press Dashboard."
					var student=null;
					$scope.flag2=true;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			
			$scope.refreshFee=function(){
				try{
					var responsePromise = $http.get(URI + "FeeAPI");
				}
				catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
					if(dataFromServer!=null){
						$scope.message=dataFromServer;
						alert($scope.message);
					}
					$scope.message=dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			
			$scope.refreshFeeManual=function(){
				try{
					var responsePromise = $http.get(URI + "FeeAPI/feeManually");
				}
				catch (err) {
					$scope.message = "There is some system Issue, Please contact Administrator";
				}
				responsePromise.success(function(dataFromServer,
						status, headers, config) {
						$scope.flag2=true;
						$scope.message=dataFromServer;
				});
				responsePromise.error(function(data, status, headers,
						config) {
					$scope.message = data;
				});
			}
			
			$scope.changeFlag2=function(){
				$scope.flag2=false;
			}
			
			$scope.setGlobal=function(data){
				student=data;
			}
			
			$scope.getGlobal=function(){
				$scope.getStudent=student;
			}
			
			$scope.setStuClass=function(data){
				stuClass=data;
			}
			
			$scope.getStuClass=function(){
				$scope.getStudentClass=stuClass;
			}
			
			$scope.getAddress=function(){
				$scope.address="H.No. "+student.studentAddress.houseNumber
				+", Sector "+student.studentAddress.sector
				+", "+student.studentAddress.city
				+", "+student.studentAddress.state
				+", "+student.studentAddress.pinCode;
			}
}]);