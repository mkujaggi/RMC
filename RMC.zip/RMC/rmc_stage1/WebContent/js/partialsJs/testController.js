var test={};
app.controller("TestController", [ '$scope', '$http', function($scope, $http) {
	$scope.addTestForm={};
	$scope.addStudentsToTestForm={};
	$scope.updateStudentMarks={};
	$scope.deleteStudentFromTestForm={};
	$scope.studentForSMS={};
	$scope.formForSMS={};
	$scope.userList={};
	$scope.testList = {};
	$scope.testMap={};
	$scope.getTest={};
	$scope.updateTest={}
	$scope.message=null;
	$scope.flag=false;
	$scope.flag1=false;
	$scope.flag2=false;
	$scope.flag3=false;
	$scope.flag4=false;
	$scope.flag5=false;
	$scope.flag6=false;
	$scope.flagForSMS=false;
	
	$scope.addNewTest=function(){
		try {
			var data = angular.toJson($scope.addTestForm);
			var responsePromise = $http.post(URI + "TestAPI",data);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.message="New test added with test Id: "+dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message = data;
		});
	}
	
	$scope.sendSMS=function(){
		$scope.formForSMS.number=$scope.studentForSMS.studentParent.parentPhNumber;
		try {
			var temp=$scope.formForSMS.message;
			$scope.formForSMS.message=temp.replace(/,/g,"comma");
			var data = angular.toJson($scope.formForSMS);
			var responsePromise = $http.post(URI + "SmsAPI",data);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.message=dataFromServer;
			$scope.flagForSMS=true;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message = data;
		});
	}
	
	$scope.setStudentForSMS=function(student){
		$scope.studentForSMS=student;
	}
	
	$scope.getStudentsById = function(testId,testClass) {
		try {
			var responsePromise = $http.get(URI + "TestAPI/getStudentsGivenTest/"+testId+"/"+testClass);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.flag1=false;
			$scope.flag=true;
			$scope.flag3=false;
			$scope.userList=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flag=false;
			$scope.flag3=true;
			$scope.message = data;
		});
	}
	
	$scope.getTestsById = function(classId) {
		try {
			var responsePromise = $http.get(URI + "TestAPI/testByClass/"+classId);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.flag=true;
			$scope.flag3=false;
			$scope.testList=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flag=false;
			$scope.flag3=true;
			$scope.message = data;
		});
	}
	
	$scope.getMarksByTestId=function(testId){
		try {
			var responsePromise = $http.get(URI + "TestAPI/testById/"+testId);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.flag=true;
			$scope.flag3=false;
			$scope.flag5=true;
			$scope.testMap=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message = data;
			$scope.flag=false;
			$scope.flag3=true;
			$scope.flag5=false;
		});
	}
	
	$scope.getStudentsByMarks=function(testId,value){
		try {
			var responsePromise = $http.get(URI + "TestAPI/getStudentsByMarks/"+testId+"/"+value);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.flag5=true;
			$scope.flag6=false;
			$scope.testMap=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.flag5=false;
			$scope.flag6=true;
			$scope.message = data;
		});
	}
	
	$scope.updateTestDetails=function(){
			$scope.updateTest.testId=$scope.getTest.testId;
			if($scope.updateTest.testName==null){
				$scope.updateTest.testName=$scope.getTest.testName;
			}
			if($scope.updateTest.testMarks==null){
				$scope.updateTest.testMarks=$scope.getTest.testMarks;
			}
			if($scope.updateTest.testDate==null){
				$scope.updateTest.testDate=$scope.getTest.testDate;
			}
			if($scope.updateTest.testClass==null){
				$scope.updateTest.testClass=$scope.getTest.testClass;
			}
			if($scope.updateTest.testTime==null){
				$scope.updateTest.testTime=$scope.getTest.testTime;
			}
			if($scope.updateTest.testDescription==null){
				$scope.updateTest.testDescription=$scope.getTest.testDescription;
			}
			try{
				var data =angular.toJson($scope.updateTest);
				var responsePromise = $http.put(URI + "TestAPI",data);
			}
			catch (err) {
				$scope.message = "There is some system Issue, Please contact Administrator";
			}
			responsePromise.success(function(dataFromServer,
					status, headers, config) {
				$scope.message="Test with ID: "+dataFromServer+" has been Updated";
			});
			responsePromise.error(function(data, status, headers,
					config) {
				$scope.message = data;
			});
	}
	
	$scope.addStudentsToTest=function(){
		try{
			var data =angular.toJson($scope.addStudentsToTestForm);
			var responsePromise = $http.put(URI + "TestAPI/updateMarks",data);
		}
		catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {

			$scope.flag1=true;
			$scope.message=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message = data;
		});
	}
	
	$scope.updateMarks=function(){
		try{
			var data =angular.toJson($scope.updateStudentMarks);
			var responsePromise = $http.put(URI + "TestAPI/updateStudentMarks",data);
		}
		catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.flag1=true;
			$scope.message=dataFromServer;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message = data;
		});
	}
	
	$scope.deleteTest=function(testId){
		try {
			var responsePromise = $http.delete(URI + "TestAPI/"+testId);
		} catch (err) {
			$scope.message = "There is some system Issue, Please contact Administrator";
		}
		responsePromise.success(function(dataFromServer,
				status, headers, config) {
			$scope.message = "Test with name "+dataFromServer+" has been deleted. Close and press Dashboard."
			var test=null;
			$scope.flag2=true;
		});
		responsePromise.error(function(data, status, headers,
				config) {
			$scope.message = data;
		});
	}
	
	$scope.deleteStudentFromTest=function(){
		if($scope.deleteStudentFromTestForm==null){
			$scope.message = "Please make a choice and then delete";
		}
		else{
			try{
				var data =angular.toJson($scope.deleteStudentFromTestForm);
				var responsePromise = $http.put(URI + "TestAPI/deleteStudentsFromTest",data);
			}
			catch (err) {
				$scope.message = "There is some system Issue, Please contact Administrator";
			}
			responsePromise.success(function(dataFromServer,
					status, headers, config) {
				$scope.flag1=true;
				$scope.message=dataFromServer;
			});
			responsePromise.error(function(data, status, headers,
					config) {
				$scope.message = data;
			});
		}
	}

	$scope.changeFlag4=function(){
		if($scope.flag4==false){
			$scope.flag4=true;
		}
		else{
			$scope.flag4=false;
		}
		$scope.flag1=false;
	}
	
	$scope.refresh=function(){
		$scope.flag4=false;
	}
	
	$scope.setGlobal=function(data){
		test=data;
	}
	
	$scope.getGlobal=function(){
		$scope.getTest=test;
	}
	
	$scope.showSMSButton=function(value){
		if(value>=60){
			return false;
		}
		else{
			return true;
		}
	}
} ])