package com.rmc.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.rmc.bean.Admin;
import com.rmc.business.service.LoginService;
import com.rmc.resources.AppConfig;
import com.rmc.resources.Factory;

@Path("/LoginAPI")
public class LoginAPI {
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAdminDetails(String dataRecieved) {
		Response returnValue = null;
		Gson gson = new Gson();
		LoginService loginService = Factory.createLoginService();
		Admin admin = gson.fromJson(dataRecieved, Admin.class);
		try {
			Admin admin2 = loginService.getAdminDetails(admin.getAdminEmail(),
					admin.getAdminPassword());
			String value = gson.toJson(admin2);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			String value = gson.toJson(message);
			if (e.getMessage().contains("DAO")) {
				returnValue = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(value).build();
			} else {
				returnValue = Response.status(Status.BAD_REQUEST).entity(value)
						.build();
			}
		}
		return returnValue;

	}
}
