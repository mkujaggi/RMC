package com.rmc.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.rmc.resources.Factory;
import com.rmc.sms.SendSMS;

@Path("/SmsAPI")
public class SmsAPI {
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response sendSMS(String dataRecieved) {
		Response returnValue = null;
		String string = dataRecieved;
		Gson gson = new Gson();
		String value1 = null;
		String userMessage = null;
		String number = null;
		SendSMS sendSMS = Factory.createSendSMS();
		string = string.substring(1, string.length() - 1);
		String[] tokens = string.split(":|,");
		for (int i = 0; i < tokens.length - 1;) {
			String key = (tokens[i++]);
			Object value = (tokens[i++]);
			if (key.contains("message")) {
				String temp = (String) value;
				String temp2=temp.replaceAll("\\\\n", System.getProperty("line.separator"));
				userMessage=temp2.replaceAll("comma", ",");
			}
			if (key.contains("number")) {
				number = "91" + (String) value;
			}
		}
		try {
			value1 = sendSMS.sendSms(userMessage, number);
			String value = gson.toJson(value1);
			returnValue = Response.ok(value).build();
		} catch (Exception e) {
			String value = gson.toJson(e);
			returnValue = Response.status(Status.BAD_REQUEST).entity(value)
					.build();
		}
		return returnValue;
	}
}
