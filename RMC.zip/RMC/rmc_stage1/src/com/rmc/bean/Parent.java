package com.rmc.bean;

public class Parent {
	private Integer parentId;
	private String parentName;
	private String parentEmail;
	private String parentPassword;
	private String parentPhNumber;

	public String getParentPhNumber() {
		return parentPhNumber;
	}

	public void setParentPhNumber(String parentPhNumber) {
		this.parentPhNumber = parentPhNumber;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentEmail() {
		return parentEmail;
	}

	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public String getParentPassword() {
		return parentPassword;
	}

	public void setParentPassword(String parentPassword) {
		this.parentPassword = parentPassword;
	}

}
