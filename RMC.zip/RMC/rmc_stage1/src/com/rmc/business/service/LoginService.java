package com.rmc.business.service;

import com.rmc.bean.Admin;

public interface LoginService {
	public Admin getAdminDetails(String email, String password) throws Exception;
}
