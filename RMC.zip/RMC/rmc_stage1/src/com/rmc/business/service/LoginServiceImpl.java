package com.rmc.business.service;

import org.apache.log4j.Logger;

import com.rmc.bean.Admin;
import com.rmc.business.validator.StudentValidator;
import com.rmc.dao.LoginDAO;
import com.rmc.resources.Factory;

public class LoginServiceImpl implements LoginService {

	@Override
	public Admin getAdminDetails(String email, String password) throws Exception {
		try {
			StudentValidator u1 = Factory.createValidator();
			LoginDAO loginDAO = Factory.createLoginDao();
			u1.isValidEmail(email);
			return loginDAO.getAdminDetails(email, password);
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}
}
