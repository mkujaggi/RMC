package com.rmc.business.service;

import java.util.HashMap;
import java.util.List;

import com.rmc.bean.Address;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;

public interface StudentService {
	public Integer addNewStudent(Student student) throws Exception;

	public List<Student> getStudentsByClass(Integer classNo) throws Exception;

	public List<Student> getStudentsByFee(Integer stuClass, Boolean value)
			throws Exception;

	public Student getStudentById(Integer studentId) throws Exception;

	public String deleteStudent(Integer studentId) throws Exception;

	public Integer updatStudent(Student student) throws Exception;

	public void updatStudentAddress(Integer studentId, Address address)
			throws Exception;

	public void updatStudentParent(Integer studentId, Parent parent)
			throws Exception;

	public void updatStudentFees(HashMap<String, String> map) throws Exception;

	public void savePicture(Integer studentId, byte[] image) throws Exception;

	public byte[] getPicture(Integer studentId) throws Exception;
}
