package com.rmc.business.validator;

import com.rmc.bean.Student;

public class StudentValidator {
	public void validateStudent(Student student) throws Exception {
		if (!isValidEmail(student.getStudentEmail())) {
			throw new Exception("Validator.INVALID_STUDENT_EMAIL");
		} else if (!isValidEmail(student.getStudentParent().getParentEmail())) {
			throw new Exception("Validator.INVALID_PARENT_EMAIL");
		} else if (!isValidPassword(student.getStudentPassword())) {
			throw new Exception("Validator.INVALID_STUDENT_PASSWORD");
		} else if (!isValidPassword(student.getStudentParent().getParentPassword())) {
			throw new Exception("Validator.INVALID_PARENT_PASSWORD");
		} else if (!isValidPincode(student.getStudentAddress().getPinCode())) {
			throw new Exception("Validator.INVALID_PINCODE");
		} else if (!isValidPhoneNumber(student.getStudentPhNumber())) {
			throw new Exception("Validator.INVALID_STUDENT_PHONE");
		} else if (!isValidPhoneNumber(student.getStudentParent().getParentPhNumber())) {
			throw new Exception("Validator.INVALID_PARENT_PHONE");
		}
	}

	public Boolean isValidEmail(String email) throws Exception {
		String regex = "[\\w]+@[\\w]+\\.[\\w]+";
		if (!email.matches(regex)) {
			return false;
		}
		return true;
	}

	public Boolean isValidPassword(String password) throws Exception {
		if (!(password.length() >= 6)) {
			return false;
		}
		return true;

	}

	public Boolean isValidPincode(Integer pinCode) throws Exception {
		int length = String.valueOf(pinCode).length();
		if (length != 6) {
			return false;
		}
		return true;
	}

	public Boolean isValidPhoneNumber(String phone) throws Exception {
		if (phone.length() == 10) {
			return true;
		}
		return false;
	}
}
