package com.rmc.dao;

public interface FeeDAO {
	public void refreshFee() throws Exception;
}
