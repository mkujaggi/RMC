package com.rmc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.bean.Address;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.entity.AddressEntity;
import com.rmc.entity.ParentEntity;
import com.rmc.entity.StudentEntity;
import com.rmc.resources.HibernateUtility;

public class StudentDAOImpl implements StudentDAO {

	@Override
	public Integer addNewStudent(Student student) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer studentId = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentEmail=?");
			q1.setParameter(0, student.getStudentEmail());
			@SuppressWarnings("unchecked")
			List<StudentEntity> list2 = q1.list();
			if (list2.isEmpty()) {
				AddressEntity ae = new AddressEntity();
				ae.setCity(student.getStudentAddress().getCity());
				ae.setHouseNumber(student.getStudentAddress().getHouseNumber());
				ae.setPinCode(student.getStudentAddress().getPinCode());
				ae.setSector(student.getStudentAddress().getSector());
				ae.setState(student.getStudentAddress().getState());
				session.save(ae);
				Query q2 = session
						.createQuery("FROM ParentEntity pe WHERE pe.parentEmail=?");
				q2.setParameter(0, student.getStudentParent().getParentEmail());
				@SuppressWarnings("unchecked")
				List<StudentEntity> list1 = q2.list();
				ParentEntity pe = new ParentEntity();
				if (list1.isEmpty()) {
					pe.setParentEmail(student.getStudentParent()
							.getParentEmail());
					pe.setParentName(student.getStudentParent().getParentName());
					pe.setParentPassword(student.getStudentParent()
							.getParentPassword());
					pe.setParentPhNumber(student.getStudentParent()
							.getParentPhNumber());
					session.save(pe);
				} else {
					throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_PARENT");
				}
				StudentEntity se = new StudentEntity();
				se.setStudentAddress(ae);
				se.setStudentClass(student.getStudentClass());
				se.setStudentDOB(student.getStudentDOB());
				se.setStudentEmail(student.getStudentEmail());
				se.setStudentFee(student.getStudentFee());
				se.setStudentGender(student.getStudentGender());
				se.setStudentName(student.getStudentName());
				se.setStudentParent(pe);
				se.setStudentPassword(student.getStudentPassword());
				se.setStudentPhNumber(student.getStudentPhNumber());
				studentId = (Integer) session.save(se);
				session.getTransaction().commit();
			} else {
				throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_STUDENT");
			}
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studentId;
	}

	@Override
	public List<Student> getStudentsByClass(Integer classNo) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Student> userResult = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentClass=?");
			q1.setParameter(0, classNo);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("UserDAO.NO_STUDENTS_IN_DATABASE");
			}
			for (StudentEntity se : list1) {
				Address a = new Address();
				a.setAddressId(se.getStudentAddress().getAddressId());
				a.setCity(se.getStudentAddress().getCity());
				a.setHouseNumber(se.getStudentAddress().getHouseNumber());
				a.setPinCode(se.getStudentAddress().getPinCode());
				a.setSector(se.getStudentAddress().getSector());
				a.setState(se.getStudentAddress().getState());
				Parent p = new Parent();
				p.setParentId(se.getStudentParent().getParentId());
				p.setParentEmail(se.getStudentParent().getParentEmail());
				p.setParentName(se.getStudentParent().getParentName());
				p.setParentPhNumber(se.getStudentParent().getParentPhNumber());
				Student s = new Student();
				s.setStudentAddress(a);
				s.setStudentParent(p);
				s.setStudentClass(se.getStudentClass());
				s.setStudentDOB(se.getStudentDOB());
				s.setStudentEmail(se.getStudentEmail());
				s.setStudentFee(se.getStudentFee());
				s.setStudentGender(se.getStudentGender());
				s.setStudentId(se.getStudentId());
				s.setStudentName(se.getStudentName());
				s.setStudentPhNumber(se.getStudentPhNumber());
				userResult.add(s);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return userResult;
	}

	@Override
	public List<Student> getStudentsByFee(Integer stuClass, Boolean value)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Student> userResult = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentFee=? AND se.studentClass=?");
			q1.setParameter(0, value);
			q1.setParameter(1, stuClass);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			if (value && list1.isEmpty()) {
				throw new Exception("UserDAO.NO_STUDENT_PAID_FEES");
			}
			if ((!(value)) && list1.isEmpty()) {
				throw new Exception("UserDAO.ALL_STUDENT_PAID_FEES");
			}
			for (StudentEntity se : list1) {
				Address a = new Address();
				a.setAddressId(se.getStudentAddress().getAddressId());
				a.setCity(se.getStudentAddress().getCity());
				a.setHouseNumber(se.getStudentAddress().getHouseNumber());
				a.setPinCode(se.getStudentAddress().getPinCode());
				a.setSector(se.getStudentAddress().getSector());
				a.setState(se.getStudentAddress().getState());
				Parent p = new Parent();
				p.setParentId(se.getStudentParent().getParentId());
				p.setParentEmail(se.getStudentParent().getParentEmail());
				p.setParentName(se.getStudentParent().getParentName());
				p.setParentPhNumber(se.getStudentParent().getParentPhNumber());
				Student s = new Student();
				s.setStudentAddress(a);
				s.setStudentParent(p);
				s.setStudentClass(se.getStudentClass());
				s.setStudentDOB(se.getStudentDOB());
				s.setStudentEmail(se.getStudentEmail());
				s.setStudentFee(se.getStudentFee());
				s.setStudentGender(se.getStudentGender());
				s.setStudentId(se.getStudentId());
				s.setStudentName(se.getStudentName());
				s.setStudentPhNumber(se.getStudentPhNumber());
				userResult.add(s);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return userResult;
	}

	@Override
	public Student getStudentById(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Student s = new Student();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q1.setParameter(0, studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			for (StudentEntity se : list1) {
				Address a = new Address();
				a.setAddressId(se.getStudentAddress().getAddressId());
				a.setCity(se.getStudentAddress().getCity());
				a.setHouseNumber(se.getStudentAddress().getHouseNumber());
				a.setPinCode(se.getStudentAddress().getPinCode());
				a.setSector(se.getStudentAddress().getSector());
				a.setState(se.getStudentAddress().getState());
				Parent p = new Parent();
				p.setParentId(se.getStudentParent().getParentId());
				p.setParentEmail(se.getStudentParent().getParentEmail());
				p.setParentName(se.getStudentParent().getParentName());
				p.setParentPhNumber(se.getStudentParent().getParentPhNumber());
				s.setStudentAddress(a);
				s.setStudentParent(p);
				s.setStudentClass(se.getStudentClass());
				s.setStudentDOB(se.getStudentDOB());
				s.setStudentEmail(se.getStudentEmail());
				s.setStudentFee(se.getStudentFee());
				s.setStudentGender(se.getStudentGender());
				s.setStudentId(se.getStudentId());
				s.setStudentName(se.getStudentName());
				s.setStudentPhNumber(se.getStudentPhNumber());
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return s;
	}

	@Override
	public String deleteStudent(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		String studName = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q1.setParameter(0, studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			studName = list1.get(0).getStudentName();
			Query q2 = session
					.createQuery("DELETE FROM StudentEntity se WHERE se.studentId=?");
			q2.setParameter(0, studentId);
			q2.executeUpdate();
			Query q3 = session
					.createQuery("DELETE FROM ParentEntity pe WHERE pe.parentId=?");
			q3.setParameter(0, list1.get(0).getStudentParent().getParentId());
			q3.executeUpdate();
			Query q4 = session
					.createQuery("DELETE FROM AddressEntity pe WHERE pe.addressId=?");
			q4.setParameter(0, list1.get(0).getStudentAddress().getAddressId());
			q4.executeUpdate();
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studName;
	}

	@Override
	public Integer updatStudent(Student student) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer studId = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q2 = session
					.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q2.setParameter(0, student.getStudentId());
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q2.list();
			for (StudentEntity se : list1) {
				if (se.getStudentEmail().equals(student.getStudentEmail())) {
					Query q1 = session
							.createQuery("UPDATE StudentEntity se SET se.studentName= :name,se.studentEmail= :email,se.studentPhNumber= :phone,se.studentDOB= :dob,se.studentClass= :class WHERE se.studentId= :id");
					q1.setParameter("name", student.getStudentName());
					q1.setParameter("email", student.getStudentEmail());
					q1.setParameter("phone", student.getStudentPhNumber());
					q1.setParameter("dob", student.getStudentDOB());
					q1.setParameter("class", student.getStudentClass());
					q1.setParameter("id", student.getStudentId());
					q1.executeUpdate();
				} else if (!se.getStudentEmail().equals(
						student.getStudentEmail())) {
					Query q3 = session
							.createQuery("FROM StudentEntity se WHERE se.studentEmail=?");
					q3.setParameter(0, student.getStudentEmail());
					@SuppressWarnings("unchecked")
					List<StudentEntity> list2 = q3.list();
					if (list2.isEmpty()) {
						Query q1 = session
								.createQuery("UPDATE StudentEntity se SET se.studentName= :name,se.studentEmail= :email,se.studentPhNumber= :phone,se.studentDOB= :dob,se.studentClass= :class WHERE se.studentId= :id");
						q1.setParameter("name", student.getStudentName());
						q1.setParameter("email", student.getStudentEmail());
						q1.setParameter("phone", student.getStudentPhNumber());
						q1.setParameter("dob", student.getStudentDOB());
						q1.setParameter("class", student.getStudentClass());
						q1.setParameter("id", student.getStudentId());
						q1.executeUpdate();
					} else {
						throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_STUDENT");
					}
				}
			}
			session.getTransaction().commit();
			session.close();
			studId = student.getStudentId();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return studId;
	}

	@Override
	public void updatStudentAddress(Integer studentId, Address address)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q1.setParameter(0, studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			Query q2 = session
					.createQuery("UPDATE AddressEntity ae SET ae.houseNumber= :number, ae.sector= :sector, ae.city= :city, ae.state= :state, ae.pinCode= :pin WHERE ae.addressId= :id");
			q2.setParameter("number", address.getHouseNumber());
			q2.setParameter("sector", address.getSector());
			q2.setParameter("city", address.getCity());
			q2.setParameter("state", address.getState());
			q2.setParameter("pin", address.getPinCode());
			q2.setParameter("id", list1.get(0).getStudentAddress()
					.getAddressId());
			q2.executeUpdate();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void updatStudentParent(Integer studentId, Parent parent)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM StudentEntity se WHERE se.studentId=?");
			q1.setParameter(0, studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q1.list();
			for (StudentEntity se : list1) {
				if (se.getStudentParent().getParentEmail()
						.equals(parent.getParentEmail())) {
					Query q2 = session
							.createQuery("UPDATE ParentEntity pe SET pe.parentName= :name, pe.parentEmail= :email, pe.parentPhNumber= :number WHERE pe.parentId= :id");
					q2.setParameter("name", parent.getParentName());
					q2.setParameter("email", parent.getParentEmail());
					q2.setParameter("number", parent.getParentPhNumber());
					q2.setParameter("id", list1.get(0).getStudentParent()
							.getParentId());
					q2.executeUpdate();
				} else if (!se.getStudentParent().getParentEmail()
						.equals(parent.getParentEmail())) {
					Query q3 = session
							.createQuery("FROM ParentEntity pe WHERE pe.parentEmail=?");
					q3.setParameter(0, parent.getParentEmail());
					@SuppressWarnings("unchecked")
					List<ParentEntity> list2 = q3.list();
					if (list2.isEmpty()) {
						Query q2 = session
								.createQuery("UPDATE ParentEntity pe SET pe.parentName= :name, pe.parentEmail= :email, pe.parentPhNumber= :number WHERE pe.parentId= :id");
						q2.setParameter("name", parent.getParentName());
						q2.setParameter("email", parent.getParentEmail());
						q2.setParameter("number", parent.getParentPhNumber());
						q2.setParameter("id", list1.get(0).getStudentParent()
								.getParentId());
						q2.executeUpdate();
					} else {
						throw new Exception("UserDAO.EMAIL_ID_TO_OTHER_PARENT");
					}
				}
			}
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}

	}

	@Override
	public void savePicture(Integer studentId, byte[] image) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			System.out.println("in dao");
			System.out.println("id " + studentId);
			System.out.println("image " + image);
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q2 = session
					.createQuery("UPDATE StudentEntity se SET se.studentImage= :image WHERE se.studentId= :id");
			q2.setParameter("image", image);
			q2.setParameter("id", studentId);
			q2.executeUpdate();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public byte[] getPicture(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		byte[] image = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q2 = session
					.createQuery("FROM StudentEntity se WHERE se.studentId= :id");
			q2.setParameter("id", studentId);
			@SuppressWarnings("unchecked")
			List<StudentEntity> list1 = q2.list();
			StudentEntity se = list1.get(0);
			image = se.getStudentImage();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return image;
	}

	@Override
	public void updatStudentFees(HashMap<String, String> map) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			for (HashMap.Entry<String, String> entry : map.entrySet()) {
				Integer key = Integer.parseInt(entry.getKey());
				Boolean value = Boolean.parseBoolean(entry.getValue());
				Query q1 = session
						.createQuery("UPDATE StudentEntity se SET se.studentFee= :fee WHERE se.studentId= :id");
				q1.setParameter("fee", value);
				q1.setParameter("id", key);
				q1.executeUpdate();
			}
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}
}
