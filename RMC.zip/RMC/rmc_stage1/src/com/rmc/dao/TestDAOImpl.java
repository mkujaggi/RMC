package com.rmc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.rmc.bean.Address;
import com.rmc.bean.Parent;
import com.rmc.bean.Student;
import com.rmc.bean.Test;
import com.rmc.entity.StudentEntity;
import com.rmc.entity.TestEntity;
import com.rmc.entity.TestStudentEntity;
import com.rmc.resources.HibernateUtility;

public class TestDAOImpl implements TestDAO {

	@Override
	public Integer addNewTest(Test test) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer testId = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			TestEntity te = new TestEntity();
			te.setTestClass(test.getTestClass());
			te.setTestDate(test.getTestDate());
			te.setTestDescription(test.getTestDescription());
			te.setTestMarks(test.getTestMarks());
			te.setTestName(test.getTestName());
			te.setTestTime(test.getTestTime());
			testId = (Integer) session.save(te);
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testId;
	}

	@Override
	public List<Test> getTestByClass(Integer classNo) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Test> testResult = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM TestEntity te WHERE te.testClass=?");
			q1.setParameter(0, classNo);
			@SuppressWarnings("unchecked")
			List<TestEntity> list1 = q1.list();
			if (list1.size() == 0) {
				throw new Exception("TestDAO.NO_TEST_IN_DATABASE");
			}
			for (TestEntity te : list1) {
				Test t = new Test();
				t.setTestClass(te.getTestClass());
				t.setTestDate(te.getTestDate());
				t.setTestDescription(te.getTestDescription());
				t.setTestId(te.getTestId());
				t.setTestMarks(te.getTestMarks());
				t.setTestName(te.getTestName());
				t.setTestTime(te.getTestTime());
				testResult.add(t);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testResult;
	}

	@Override
	public Test getTestById(Integer testId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Test t = new Test();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM TestEntity te WHERE te.testId=?");
			q1.setParameter(0, testId);
			@SuppressWarnings("unchecked")
			List<TestEntity> list1 = q1.list();
			for (TestEntity te : list1) {
				t.setTestClass(te.getTestClass());
				t.setTestDate(te.getTestDate());
				t.setTestDescription(te.getTestDescription());
				t.setTestId(te.getTestId());
				t.setTestMarks(te.getTestMarks());
				t.setTestName(te.getTestName());
				t.setTestTime(te.getTestTime());
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return t;
	}

	@Override
	public List<Student> getStudentsByMarks(Integer testId, Boolean value)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Student> list2 = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			if (value) {
				Query q1 = session
						.createQuery("FROM TestStudentEntity tse WHERE tse.testId= :id AND tse.marksObtained>= :marks");
				q1.setParameter("marks", 60);
				q1.setParameter("id", testId);
				@SuppressWarnings("unchecked")
				List<TestStudentEntity> result = q1.list();
				if (result.isEmpty()) {
					throw new Exception("TestDAO.NO_STUDENTS_FOUND");
				} else {
					for (TestStudentEntity tse : result) {
						Query q2 = session
								.createQuery("FROM StudentEntity se WHERE se.studentId= :id");
						q2.setParameter("id", tse.getStudentId());
						@SuppressWarnings("unchecked")
						List<StudentEntity> stuList = q2.list();
						StudentEntity se = stuList.get(0);
						Student s = new Student();
						s.setStudentId(se.getStudentId());
						s.setStudentName(se.getStudentName());
						s.setStudentPhNumber(se.getStudentPhNumber());
						s.setStudentMarks(tse.getMarksObtained());
						list2.add(s);
					}
				}
			} else if (!value) {
				Query q1 = session
						.createQuery("FROM TestStudentEntity tse WHERE tse.testId= :id AND tse.marksObtained< :marks");
				q1.setParameter("marks", 60);
				q1.setParameter("id", testId);
				@SuppressWarnings("unchecked")
				List<TestStudentEntity> result = q1.list();
				if (result.isEmpty()) {
					throw new Exception("TestDAO.NO_STUDENTS_FOUND");
				} else {
					for (TestStudentEntity tse : result) {
						Query q2 = session
								.createQuery("FROM StudentEntity se WHERE se.studentId= :id");
						q2.setParameter("id", tse.getStudentId());
						@SuppressWarnings("unchecked")
						List<StudentEntity> stuList = q2.list();
						StudentEntity se = stuList.get(0);
						Student s = new Student();
						s.setStudentId(se.getStudentId());
						s.setStudentName(se.getStudentName());
						s.setStudentPhNumber(se.getStudentPhNumber());
						s.setStudentMarks(tse.getMarksObtained());
						list2.add(s);
					}
				}
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return list2;
	}

	@Override
	public List<Student> getStudentsGivenTest(Integer testId, Integer testClass)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Student> list2 = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM TestStudentEntity tse WHERE tse.testId= :id");
			q1.setParameter("id", testId);
			@SuppressWarnings("unchecked")
			List<TestStudentEntity> result = q1.list();
			if (result.isEmpty()) {
				Query q2 = session
						.createQuery("FROM StudentEntity se WHERE se.studentClass= :class");
				q2.setParameter("class", testClass);
				@SuppressWarnings("unchecked")
				List<StudentEntity> list1 = q2.list();
				for (StudentEntity se : list1) {
					Student s = new Student();
					s.setStudentId(se.getStudentId());
					s.setStudentName(se.getStudentName());
					s.setStudentPhNumber(se.getStudentPhNumber());
					list2.add(s);
				}
			} else {
				Query q2 = session
						.createQuery("FROM StudentEntity se WHERE se.studentClass= :class");
				q2.setParameter("class", testClass);
				@SuppressWarnings("unchecked")
				List<StudentEntity> list1 = q2.list();
				List<StudentEntity> tempList = new ArrayList<>();
				for (TestStudentEntity tse : result) {
					if (!(tse.getMarksObtained().equals(null))) {
						for (StudentEntity se : list1) {
							if (se.getStudentId().equals(tse.getStudentId())) {
								tempList.add(se);
							} else {
								continue;
							}
						}
					} else {
						for (StudentEntity se : list1) {
							if (se.getStudentId().equals(tse.getStudentId())) {
								continue;
							} else {
								tempList.add(se);
							}
						}
					}
				}
				list1.removeAll(tempList);
				for (StudentEntity se : list1) {
					Student s = new Student();
					s.setStudentId(se.getStudentId());
					s.setStudentName(se.getStudentName());
					s.setStudentPhNumber(se.getStudentPhNumber());
					list2.add(s);
				}
			}
			if (list2.isEmpty()) {
				throw new Exception("TestDAO.ALL_STUDENTS_GIVEN_TEST");
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return list2;
	}

	@Override
	public List<Student> getMarksForTest(Integer testId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Student> list2 = new ArrayList<>();
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM TestStudentEntity tse WHERE tse.testId=?");
			q1.setParameter(0, testId);
			@SuppressWarnings("unchecked")
			List<TestStudentEntity> result = q1.list();
			for (TestStudentEntity tse : result) {
				Query q2 = session
						.createQuery("FROM StudentEntity se WHERE se.studentId=?");
				q2.setParameter(0, tse.getStudentId());
				@SuppressWarnings("unchecked")
				List<StudentEntity> list1 = q2.list();
				StudentEntity se = list1.get(0);
				Address a = new Address();
				a.setAddressId(se.getStudentAddress().getAddressId());
				a.setCity(se.getStudentAddress().getCity());
				a.setHouseNumber(se.getStudentAddress().getHouseNumber());
				a.setPinCode(se.getStudentAddress().getPinCode());
				a.setSector(se.getStudentAddress().getSector());
				a.setState(se.getStudentAddress().getState());
				Parent p = new Parent();
				p.setParentId(se.getStudentParent().getParentId());
				p.setParentEmail(se.getStudentParent().getParentEmail());
				p.setParentName(se.getStudentParent().getParentName());
				p.setParentPhNumber(se.getStudentParent().getParentPhNumber());
				Student s = new Student();
				s.setStudentAddress(a);
				s.setStudentParent(p);
				s.setStudentId(se.getStudentId());
				s.setStudentName(se.getStudentName());
				s.setStudentPhNumber(se.getStudentPhNumber());
				s.setStudentMarks(tse.getMarksObtained());
				list2.add(s);
			}
			if (list2.isEmpty()) {
				throw new Exception("TestDAO.NO_STUDENTS_GIVEN_TEST");
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return list2;
	}

	@Override
	public String deleteTest(Integer testId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		String testName = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("FROM TestEntity te WHERE te.testId=?");
			q1.setParameter(0, testId);
			@SuppressWarnings("unchecked")
			List<TestEntity> list1 = q1.list();
			testName = list1.get(0).getTestName();
			Query q2 = session
					.createQuery("DELETE FROM TestEntity te WHERE te.testId=?");
			q2.setParameter(0, testId);
			q2.executeUpdate();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testName;
	}

	@Override
	public Integer updatTest(Test test) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer testId = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Query q1 = session
					.createQuery("UPDATE TestEntity te SET te.testName= :name,te.testDescription= :desc,te.testDate= :date,te.testMarks= :marks,te.testTime= :time,te.testClass= :class WHERE te.testId= :id");
			q1.setParameter("name", test.getTestName());
			q1.setParameter("desc", test.getTestDescription());
			q1.setParameter("date", test.getTestDate());
			q1.setParameter("marks", test.getTestMarks());
			q1.setParameter("time", test.getTestTime());
			q1.setParameter("class", test.getTestClass());
			q1.setParameter("id", test.getTestId());
			q1.executeUpdate();
			session.getTransaction().commit();
			session.close();
			testId = test.getTestId();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		return testId;
	}

	@Override
	public void updateMarks(HashMap<String, HashMap<String, Integer>> map)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			for (Entry<String, HashMap<String, Integer>> entry : map.entrySet()) {
				Integer key = Integer.parseInt(entry.getKey());
				HashMap<String, Integer> value = entry.getValue();
				for (Entry<String, Integer> entry1 : value.entrySet()) {
					Integer key1 = Integer.parseInt(entry1.getKey());
					Integer value1 = entry1.getValue();
					TestStudentEntity tse = new TestStudentEntity();
					tse.setTestId(key);
					tse.setStudentId(key1);
					tse.setMarksObtained(value1);
					session.save(tse);
				}
			}
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void updateStudentMarks(HashMap<String, HashMap<String, Integer>> map)
			throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			for (Entry<String, HashMap<String, Integer>> entry : map.entrySet()) {
				Integer key = Integer.parseInt(entry.getKey());
				HashMap<String, Integer> value = entry.getValue();
				for (Entry<String, Integer> entry1 : value.entrySet()) {
					Integer key1 = Integer.parseInt(entry1.getKey());
					Integer value1 = entry1.getValue();
					if (value1 == null) {
						continue;
					} else {
						Query q3 = session
								.createQuery("UPDATE TestStudentEntity tse SET tse.marksObtained= :marks WHERE tse.studentId= :id AND tse.testId= :id2");
						q3.setParameter("marks", value1);
						q3.setParameter("id", key1);
						q3.setParameter("id2", key);
						q3.executeUpdate();
					}
				}
			}
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

	@Override
	public void deleteStudentFromTest(
			HashMap<String, HashMap<String, Boolean>> map) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			for (Entry<String, HashMap<String, Boolean>> entry : map.entrySet()) {
				Integer key = Integer.parseInt(entry.getKey());
				HashMap<String, Boolean> value = entry.getValue();
				for (Entry<String, Boolean> entry1 : value.entrySet()) {
					Integer key1 = Integer.parseInt(entry1.getKey());
					Boolean value1 = entry1.getValue();
					if (value1 == false) {
						continue;
					} else {
						Query q3 = session
								.createQuery("DELETE FROM TestStudentEntity tse WHERE tse.studentId= :id AND tse.testId= :id2");
						q3.setParameter("id", key1);
						q3.setParameter("id2", key);
						q3.executeUpdate();
					}
				}
			}
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/com/rmc/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}

}
