package com.rmc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PARENT")
public class ParentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PARENT_ID")
	private Integer parentId;
	@Column(name = "PARENT_NAME")
	private String parentName;
	@Column(name = "PARENT_EMAIL")
	private String parentEmail;
	@Column(name = "PARENT_PASSWORD")
	private String parentPassword;
	@Column(name = "PARENT_MOBILE_NO")
	private String parentPhNumber;

	public String getParentPhNumber() {
		return parentPhNumber;
	}

	public void setParentPhNumber(String parentPhNumber) {
		this.parentPhNumber = parentPhNumber;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentEmail() {
		return parentEmail;
	}

	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public String getParentPassword() {
		return parentPassword;
	}

	public void setParentPassword(String parentPassword) {
		this.parentPassword = parentPassword;
	}

}
