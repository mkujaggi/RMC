package com.rmc.resources;

import com.rmc.business.service.FeeService;
import com.rmc.business.service.FeeServiceImpl;
import com.rmc.business.service.LoginServiceImpl;
import com.rmc.business.service.StudentService;
import com.rmc.business.service.StudentServiceImpl;
import com.rmc.business.service.TestService;
import com.rmc.business.service.TestServiceImpl;
import com.rmc.business.validator.StudentValidator;
import com.rmc.dao.FeeDAO;
import com.rmc.dao.FeeDAOImpl;
import com.rmc.dao.LoginDAOImpl;
import com.rmc.dao.StudentDAO;
import com.rmc.dao.StudentDAOImpl;
import com.rmc.dao.TestDAO;
import com.rmc.dao.TestDAOImpl;
import com.rmc.sms.SendSMS;
import com.rmc.sms.SendSMSImpl;

public class Factory {
	public static LoginDAOImpl createLoginDao() {
		return new LoginDAOImpl();
	}

	public static LoginServiceImpl createLoginService() {
		return new LoginServiceImpl();
	}

	public static StudentValidator createValidator() {
		return new StudentValidator();
	}

	public static StudentDAO createStudentDAO() {
		return new StudentDAOImpl();
	}

	public static StudentService createStudentService() {
		return new StudentServiceImpl();
	}

	public static TestService createTestService() {
		return new TestServiceImpl();
	}

	public static TestDAO createTestDAO() {
		return new TestDAOImpl();
	}

	public static FeeService createFeeService() {
		return new FeeServiceImpl();
	}

	public static FeeDAO createFeeDAO() {
		return new FeeDAOImpl();
	}
	
	public static SendSMS createSendSMS() {
		return new SendSMSImpl();
	}
}
